<?php

//$D["snippet"]["display"]["fmtString"] = "%s (%d)";
//$D["snippet"]["display"]["field"] = array( "title", "id" );

$D["snippet"]["inhibit"]["clone"] = false;

$D["snippet"]["preUpdate"] = "custom/checkdata.php";

$D["snippet"]["postUpdate"] = "custom/updatelastmod.php";

$D["snippet"]["postAuth"] = "custom/authcat.php";

$D["snippet"]["loadForm"] = "custom/snippetform.php";

$D["snippet"]["filter"] = array();
$D["snippet"]["filter"]["title"]["type"] = t;
$D["snippet"]["filter"]["title"]["label"] = "Title";
$D["snippet"]["filter"]["text"]["type"] = t;
$D["snippet"]["filter"]["text"]["label"] = "Text";
$D["snippet"]["filter"]["approved"]["type"] = b;
$D["snippet"]["filter"]["approved"]["label"] = "Approved";
$D["snippet"]["filter"]["snippet"]["type"] = t;
$D["snippet"]["filter"]["snippet"]["label"] = "Snippet";
$D["snippet"]["filter"]["category"]["type"] = s;
$D["snippet"]["filter"]["category"]["label"] = "Directory";
$D["snippet"]["filter"]["owner_usr->login"]["type"] = t;
$D["snippet"]["filter"]["owner_usr->login"]["label"] = "Author";
$D["snippet"]["filter"]["large"]["type"] = b;
$D["snippet"]["filter"]["large"]["label"] = "Large";
$D["snippet"]["filter"]["standalone"]["type"] = b;
$D["snippet"]["filter"]["standalone"]["label"] = "Standalone";

$D["snippet"]["orderBy"] = "title";

$logged = isset($_ERW_db) && isset($_SERVER['PHP_AUTH_USER']) &&
	($pw = ERW::getOne("password from usr where login=".ERW::quote($_SERVER['PHP_AUTH_USER']))) && $pw == $_SERVER['PHP_AUTH_PW'];

$D["snippet"]["inhibit"]["main"]["chown"] = true;

if (!$logged) {
	$D["snippet"]["inhibit"]["main"]["new"] = true;
	$D["snippet"]["inhibit"]["main"]["delete"] = true;
}

$D["snippet"]["button"]["main"] = array();

if ($logged) $D["snippet"]["button"]["main"][] =
		array(
			"label" => "Preview",
			"name" => "preview",
			"help" => "Preview the selected snippet",
			"events" => array(
				"onclick" => 
					"if ((i = getSelectedId('m_snippet')) < 0) alert('No snippet has been selected'); else openServiceWindow('http://lsr.di.unimi.it/LSR/Item?u=1&id='+i)"
			)
		);

if ($logged) $D["snippet"]["button"]["main"][] =
		array(
			"label" => "Generate tarball",
			"name" => "generate",
			"help" => "Generate the Lilypond snippet and documentation tarballs",
			"events" => array(
				"onclick" => 
					"openServiceWindow('http://lsr.di.unimi.it/generate.php')"
			)
		);

if (!$logged) $D["snippet"]["button"]["main"][] = 
		array(
			"label" => "Log in",
			"name" => "login",
			"events" => array(
				"onclick" => "window.location='login.php?url=".urlencode("https://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"])."'"
			)
		);

$D["snippet"]["button"]["main"][] =
		array(
			"label" => "Download LSR",
			"name" => "Download",
			"help" => "Go to the Lilypond Snippet Repository download section",
			"events" => array(
				"onclick" => "window.open('http://lsr.di.unimi.it/download')"
			)
		);

$D["snippet"]["button"]["main"][] =
		array(
			"label" => "Lilypond Snippet Repository ♪♫",
			"name" => "LSR",
			"help" => "Go back to the Lilypond Snippet Repository",
			"events" => array(
				"onclick" => "window.location='http://lsr.di.unimi.it/'"
			)
		);

?>