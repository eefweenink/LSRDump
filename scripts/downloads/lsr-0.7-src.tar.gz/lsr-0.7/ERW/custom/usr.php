<?php

$D["usr"]["type"]["password"] = pw;

$D["usr"]["inhibit"]["clone"] = true;
$D["usr"]["inhibit"]["save"] = true;

$D["usr"]["inhibit"]["main"]["chown"] = true;

$D["usr"]["postUpdate"] = "custom/fixusrowner.php";

$logged = isset($_ERW_db) && isset($_SERVER['PHP_AUTH_USER']) &&
	($pw = ERW::getOne("password from usr where login=".ERW::quote($_SERVER['PHP_AUTH_USER']))) && $pw == $_SERVER['PHP_AUTH_PW'];

$D["usr"]["button"]["main"] = array();

if (!$logged) $D["usr"]["button"]["main"][] =
		array(
			"label" => "Log in",
			"name" => "login",
			"events" => array(
				"onclick" => "window.location='login.php?url=".urlencode("https://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"])."'"
			)
		);

$D["usr"]["button"]["main"][] =
		array(
			"label" => "Lilypond Snippet Repository ♪♫",
			"name" => "LSR",
			"events" => array(
				"onclick" => 
					"window.location='http://lsr.di.unimi.it/'"
			)
		);


?>