<?php

/* This script must be installed in the root directory of LSR. It provides authentication facilities. */

require_once("ERW.php");
ERW::init();
ERW::checkBrowser();
ERW::localise();

if (!isset($_ERW_db)) ERW::connect();

if (!isset($_SERVER['PHP_AUTH_USER']) || 
		!($pw = ERW::getOne("password from usr where login=".ERW::quote($_SERVER['PHP_AUTH_USER']))) ||
		$pw != $_SERVER['PHP_AUTH_PW']) {
	header('WWW-Authenticate: Basic realm="Lilypond Snippet Repository"');
	header('HTTP/1.0 401 Unauthorized');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Strict//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Lilypond Snippet Repository ♪♫</title>
  </head>
  <body>
	<h1>Authentication failed</h1>
  </body>
</html>
<?php
}
else header("Location: ".$_GET["url"]);
?>