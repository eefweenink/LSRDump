<?php

global $id;

ERW::query("update usr set id_owner_usr=id where id=$id");

return null;

?>