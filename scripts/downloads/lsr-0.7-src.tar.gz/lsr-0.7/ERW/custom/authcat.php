<?php
if ($arg["id"] != 0 && ERW::getOne("approved from snippet where id=".$arg["id"]) == "0" &&
	ERW::getOne("id_owner_usr from snippet where id=".$arg["id"]) == $_ERW_userId) {
		$arg["auth"]["update"] = true;
		$arg["auth"]["delete"] = true;
}
?>
