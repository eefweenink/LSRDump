<?php

global $id;

ERW::query("update snippet set lastmoddate=CURRENT_DATE, lastmodtime=CURRENT_TIME where id=$id");

return null;

?>