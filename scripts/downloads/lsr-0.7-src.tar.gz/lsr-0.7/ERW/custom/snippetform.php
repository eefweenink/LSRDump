<?php
if (ERW::getOne("name from grp where id=$userGrp") == "editors"
	|| ERW::getOne("login from usr where id=$userId") == "admin" ) return "snippet";

return "snippetro";
?>
