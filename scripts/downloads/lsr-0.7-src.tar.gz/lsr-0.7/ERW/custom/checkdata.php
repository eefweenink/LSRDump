<?php

global $q;

function fileFromString($dir, $s, $suffix) {
	$filename = ERW::xmkstemp($dir, "LSR", $suffix);
	$h = fopen($filename, "w");
	fwrite($h, $s);
	fclose($h);
	return $filename;
}

// First we check whether there are duplicate tags

$tags = array();
$tagcount = 0;
for($i=0; $i<=6;  $i++) if ($q["snippet"]["tag{$i}_tag"] != "NULL") {
	$tagcount++;
	$tags[$q["snippet"]["tag{$i}_tag"]] = true;
}

if (count($tags) != $tagcount) return "Please remove duplicate tags";

// Then we check that the HTML is OK

$texttype = ERW::unquote($q["snippet"]["texttype"]);
$text = ERW::unquote($q["snippet"]["text"]);

if ($texttype == "F") $text = "<html><head><title></title>$text</body></html>";

if ($texttype != "T") {
	$filename = fileFromString("/tmp", $text, ".html");

	$output = array();
	$command = "/usr/bin/tidy -wrap 0 -utf8 -e -q $filename </dev/null 2>&1";
	error_log("+ $command");
	exec("$command", $output, $exitValue);
	foreach($output as $l) error_log($l);
	unlink($filename);
	
	if (count($output)>20) {
		$output = array_splice($output, 0, 20);
		$output[] = "\n...";
	}
	

	if ($exitValue == 2) return "Error running tidy on ".($texttype == "F" ? " an HTML fragment" : " a full HTML document").":\n".implode("\n", $output);
}

// Then we check that the snippet actually compiles

$currDir = getcwd();
chdir("/mnt/lilyjail/tmp");

$filename = fileFromString(".", ERW::unquote($q["snippet"]["snippet"]), ".ly");
$basename = basename($filename);
$output = array();
$basenamenoext = substr($basename, 0, strlen($basename) - 3);

// The --eps option must be there so that gs is not invoked to generate the PDF output (it will fail as we're running jailed).

$command = "sudo /usr/bin/lilypond -jlsr,lsr,/mnt/lilyjail,/tmp -dbackend=eps --eps -dtall-page-formats=eps -dno-use-paper-size-for-page $basename >/mnt/lilyjail/tmp/$basenamenoext.log 2>&1";
error_log("+ $command");
exec($command, $output, $exitValue);

foreach($output as $l) error_log($l);

$log = file("/mnt/lilyjail/tmp/$basenamenoext.log");

unlink($filename);

if (count($log)>20) {
	$log = array_splice($log, 0, 20);
	$log[] = "\n...";
}

$nooutput = !file_exists("{$basenamenoext}.eps") && !file_exists("{$basenamenoext}-1.eps");

exec("rm -f $basenamenoext*.tex* $basenamenoext*.eps $basenamenoext.midi");

chdir($currDir);

if ($exitValue) return "Error running Lilypond:\n".implode("\n", $log);
if ($nooutput) return "No output from Lilypond";

return null;

?>