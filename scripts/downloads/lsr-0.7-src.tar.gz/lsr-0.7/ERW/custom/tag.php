<?php

$D["tag"]["orderBy"] = "priority desc";

?>