/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.commons.collections.ExtendedProperties;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.tools.view.servlet.VelocityViewServlet;

import it.unimi.dsi.lsr.Constants;

/**
 * The base servlet for LSR. It just sets up the global environment. The static methods
 * {@link #loadConfiguration(VelocityViewServlet, ExtendedProperties)} and {@link #init()} are used
 * by {@link SearchPage} in a mixin-like fashion, as we do not have multiple inheritance.
 */

public abstract class LsrServlet extends VelocityViewServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * We overwrite this method because Velocity's concept of "current directory" is the directory where
	 * you started Tomcat. Go figure.
	 */

	@Override
	protected ExtendedProperties loadConfiguration(final ServletConfig config) throws FileNotFoundException, IOException {
		final ExtendedProperties p = super.loadConfiguration(config);
		return loadConfiguration(this, p);
	}

	protected static ExtendedProperties loadConfiguration(final VelocityViewServlet servlet, final ExtendedProperties p) {
		final ServletContext context = servlet.getServletContext();

		// Relativize paths
		String log = p.getString(Velocity.RUNTIME_LOG);
		if (log != null) {
			log = context.getRealPath(log);
			if (log != null) p.setProperty(Velocity.RUNTIME_LOG, log);
		}

		String path = p.getString(Velocity.FILE_RESOURCE_LOADER_PATH);
		if (path != null) {
			path = context.getRealPath(path);
			if (path != null) p.setProperty(Velocity.FILE_RESOURCE_LOADER_PATH, path);
		}

		return p;
	}

	@Override
	public void init() throws ServletException {
		super.init();
		init(this);
	}

	@SuppressWarnings("deprecation")
	public static void init(final VelocityViewServlet servlet) throws ServletException {
		// Ensures JVM-wide loading of the mysql driver

		final ServletContext context = servlet.getServletContext();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (final Exception e) {
			throw new ServletException(e);
		}

		final String dburi = servlet.getInitParameter("dburi");
		context.setAttribute("dburi", dburi != null ? dburi : Constants.DB_URI);

		final String lilyOpts = servlet.getInitParameter("lilyopts");
		context.setAttribute("lilyopts", lilyOpts != null ? lilyOpts : Constants.LILY_OPTS);

		final String usr = servlet.getInitParameter("usr");
		context.setAttribute("usr", usr != null ? usr : Constants.USR);

		final String tempDir = servlet.getInitParameter("tempdir");
		context.setAttribute("tempdir", tempDir != null ? tempDir : Constants.TEMP_DIR);
	}
}
