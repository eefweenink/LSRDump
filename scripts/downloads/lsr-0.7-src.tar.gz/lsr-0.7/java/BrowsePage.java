
/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.IOException;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.ccil.cowan.tagsoup.Parser;
import org.jsoup.Jsoup;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import it.unimi.dsi.lang.MutableString;

/**
 * The browsing servlet for LSR.
 *
 * <P>
 * This servlet scans the entire archive, showing the entire snippet descriptions.
 *
 * @author Sebastiano Vigna
 * @since 0.2
 */
public class BrowsePage extends LsrServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * Standard maximum number of items to be displayed (may be altered with the <samp>m</samp> query
	 * parameter).
	 */
	private final static int STD_MAX_NUM_ITEMS = 10;

	private static final class HTMLContentHandler implements ContentHandler {
		private final ReferenceOpenHashSet<String> discard = new ReferenceOpenHashSet<>(new String[] { "html", "body",
				"head", "meta", "style" });
		private int ignoring;
		public MutableString result = new MutableString();

		@Override
		public void startDocument() throws SAXException {
			ignoring = 0;
			result.length(0);
		}

		@Override
		public void characters(final char[] ch, final int start, final int length) throws SAXException {
			if (ignoring == 0) result.append(ch, start, length);
		}

		@Override
		public void endElement(final String namespaceURI, final String localName, final String qName) throws SAXException {
			if (discard.contains(qName)) return;
			if ("script".equalsIgnoreCase(localName) || "style".equalsIgnoreCase(localName)) ignoring--;
			else if (ignoring == 0) result.append("</" + localName + ">");
		}

		@Override
		public void ignorableWhitespace(final char[] ch, final int start, final int length) throws SAXException {
			if (ignoring == 0) result.append(new String(ch, start, length));
		}

		@Override
		public void startElement(final String namespaceURI, final String localName, final String qName, final Attributes atts) throws SAXException {
			if (discard.contains(qName)) return;
			if ("script".equalsIgnoreCase(localName) || "style".equalsIgnoreCase(localName)) ignoring++;
			else if (ignoring == 0) {
				result.append("<" + localName);
				for (int i = 0; i < atts.getLength(); i++) {
					result.append(' ');
					result.append(atts.getLocalName(i));
					result.append("=\"");
					result.append(StringEscapeUtils.escapeHtml(atts.getValue(i)));
					result.append('"');
				}

				result.append('>');
			}
		}

		@Override
		public void endDocument() throws SAXException {
		}

		@Override
		public void endPrefixMapping(final String prefix) throws SAXException {
		}

		@Override
		public void processingInstruction(final String target, final String data) throws SAXException {
		}

		@Override
		public void setDocumentLocator(final Locator locator) {
		}

		@Override
		public void skippedEntity(final String name) throws SAXException {
		}

		@Override
		public void startPrefixMapping(final String prefix, final String uri) throws SAXException {
		}

	}

	@Override
	public Template handleRequest(final HttpServletRequest request, final HttpServletResponse response, final Context context) throws IOException {
		Template template = null;

		try {
			// Sanitise parameters.
			int start = 0, maxNumItems = STD_MAX_NUM_ITEMS, date = 0;
			try {
				maxNumItems = Integer.parseInt(request.getParameter("m"));
			} catch (final NumberFormatException dontCare) {
			}
			try {
				start = Integer.parseInt(request.getParameter("s"));
			} catch (final NumberFormatException dontCare) {
			}
			try {
				date = Integer.parseInt(request.getParameter("d"));
			} catch (final NumberFormatException dontCare) {
			}

			if (maxNumItems < 0 || maxNumItems > 1000) maxNumItems = STD_MAX_NUM_ITEMS;
			if (start < 0) start = 0;

			context.put("firstItem", Integer.valueOf(start));

			final ServletContext servletContext = getServletContext();

			final Connection connection = DriverManager.getConnection((String)servletContext.getAttribute("dburi"));
			final Statement s = connection.createStatement();

			ResultSet rs = s.executeQuery("select id,title,text,texttype from snippet where approved='1' order by " + (date != 0 ? "lastmoddate" : "title") + " limit " + start + "," + maxNumItems);

			final Parser parser = new Parser();
			final HTMLContentHandler contentHandler = new HTMLContentHandler();
			parser.setContentHandler(contentHandler);
			final ObjectArrayList<BrowseItem> resultItems = new ObjectArrayList<>();
			final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();

			while (rs.next()) {
				final BrowseItem item = new BrowseItem(rs.getInt("id"));
				resultItems.add(item);
				final String text = decoder.decode(ByteBuffer.wrap(rs.getBytes("text"))).toString();
				final String title = decoder.decode(ByteBuffer.wrap(rs.getBytes("title"))).toString();
				item.title = title;
				item.alt = StringEscapeUtils.escapeHtml(Jsoup.parse(title).text());

				if ("T".equals(rs.getString("texttype"))) item.text = StringEscapeUtils.escapeHtml(text);
				else {
					parser.parse(new InputSource(new StringReader(text)));
					item.text = contentHandler.result.toString();
				}
			}

			rs = s.executeQuery("select COUNT(*) from snippet where approved='1'");
			rs.next();
			context.put("globNumItems", Integer.valueOf(rs.getInt(1)));
			context.put("result", resultItems);
			context.put("start", Integer.valueOf(start));
			context.put("d", Integer.valueOf(date));
			context.put("maxNumItems", Integer.valueOf(maxNumItems));

			rs.close();
			s.close();
			connection.close();
			template = getTemplate("browse.vm");
		} catch (final Exception e) {
			e.printStackTrace(System.err);
		}

		return template;
	}
}
