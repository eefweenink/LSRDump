package it.unimi.dsi.lsr;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import it.unimi.dsi.fastutil.bytes.ByteArrayList;


/**
 * Fixes re-encoded UTF-8 text. *
 *
 * @author Sebastiano Vigna
 * @since 0.6
 */
public class FixUTF8 {

	private FixUTF8() {}

 	@SuppressWarnings("deprecation")
	public static void fix(final String dbUri) throws SQLException, IOException, InstantiationException, ClassNotFoundException, IllegalAccessException {
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
 		final Connection connection = DriverManager.getConnection( dbUri );

		final Statement s = connection.createStatement ();
		final ResultSet rs = s.executeQuery("select id,title,snippet,text from snippet");
		final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();

		while ( rs.next () ) {
			final int id = rs.getInt("id");
			for (final String field : new String[] { "title", "snippet", "text" }) {
				final String content = rs.getString(field);
				int noniso = 0, utf8 = 0;
				boolean prevNonASCII = false;
				for (final char c : content.toCharArray()) {
					if (c >= 256) utf8++;
					else if (c >= 128 && prevNonASCII) noniso++;
					prevNonASCII = c >= 128;
				}

				if (utf8 > 0) continue; // Already UTF-8
				if (noniso == 0) continue; // Almost nothing weird

				System.out.println("\n*********** Fixing field " + field + " in snippet \"" + rs.getString("title") + "...");

				final ByteArrayList l = new ByteArrayList();
				for (final char c : content.toCharArray()) l.add((byte)(c));
				System.out.println("Old " + field + ": " + content);
				System.out.println();
				System.out.println();

				String decoded;
				try {
					decoded = decoder.decode(ByteBuffer.wrap(l.toByteArray())).toString();
				} catch (final MalformedInputException e) {
					decoded = null;
				}

				if (decoded != null) {
					System.out.println("New " + field + ": " + decoded);

					final PreparedStatement update = connection.prepareStatement("update snippet set " + field + "=? where id=?");
					update.setString(1, decoded);
					update.setInt(2, id);
					System.out.println("UPDATE: " + update);
					update.execute();
					update.close();
				}
				else System.out.println("Undecodable field");
				System.out.println();
				System.out.println();
			}
		}

		rs.close();
		s.close();
		connection.close();
 	}

	public static void main(final String[] arg) throws SQLException, IOException, InstantiationException, ClassNotFoundException, IllegalAccessException {
		fix(Constants.DB_URI);
	}
}
