package it.unimi.dsi.lsr;

/*
 * Copyright (C) 2009-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.lang.MutableString;

/**
 * Installs new snippets by matching titles with filenames.
 *
 * @author Sebastiano Vigna
 * @since 0.3
 */
public class UpdateFromSnippets {

	private UpdateFromSnippets() {
	}

	@SuppressWarnings("deprecation")
	public static void main(final String[] arg) throws SQLException, IOException, InstantiationException, ClassNotFoundException, IllegalAccessException {

		if (arg.length == 0) {
			System.err.println("UpdateFromSnippet <SNIPPETDIR>");
			return;
		}

		final File snippetDir = new File(arg[0]);

		final Collection<File> snippets = FileUtils.listFiles(snippetDir, new String[] { "ly" }, false);

		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		final Connection connection = DriverManager.getConnection(Constants.DB_URI);

		final Statement s = connection.createStatement();
		final ResultSet rs = s.executeQuery("select id,title from snippet");

		// Note: this MUST be in sync with Database2Snippets!
		final MutableString title = new MutableString();
		final char[] toBeReplaced = new char[] { ' ', '"', '*', '/', ':', '<', '>', '?', '\\', '|', '_', ';' },
				replacements = new char[] { '-', '\'', '+', '-', '-', '-', '-', '-', '-', '-', '-', '-' },
				toBeDeleted = new char[] { '(', ')', '\'' };
		final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();

		final Int2ObjectOpenHashMap<InputStream> newContent = new Int2ObjectOpenHashMap<>();

		while (rs.next()) {
			title.replace(Jsoup.parse(decoder.decode(ByteBuffer.wrap(rs.getBytes("title"))).toString()).text());
			title.replace(toBeReplaced, replacements);
			title.delete(toBeDeleted);
			title.toLowerCase();
			final File file = new File(snippetDir, title.append(".ly").toString());

			if (file.exists()) {
				newContent.put(rs.getInt("id"), new FileInputStream(file));
				snippets.remove(file);
			} else System.out.println("Missing snippet: " + title);
		}

		rs.close();

		final PreparedStatement update = connection.prepareStatement("update snippet set snippet=?,lastmoddate=?,lastmodtime=? where id=?");

		for (final Int2ObjectMap.Entry<InputStream> e : newContent.int2ObjectEntrySet()) {
			update.setBinaryStream(1, e.getValue(), Integer.MAX_VALUE);
			update.setDate(2, new Date(System.currentTimeMillis()));
			update.setTime(3, new Time(System.currentTimeMillis()));
			update.setInt(4, e.getIntKey());
			update.execute();
		}

		update.close();

		System.out.println("Installed " + newContent.size() + " new snippets");
		System.out.println("Unknown files: " + snippets);
	}
}
