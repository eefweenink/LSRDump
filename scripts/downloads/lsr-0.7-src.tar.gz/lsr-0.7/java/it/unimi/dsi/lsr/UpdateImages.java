package it.unimi.dsi.lsr;

/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Collection;
import java.util.Collections;

import org.apache.commons.lang.StringUtils;

import it.unimi.dsi.fastutil.io.FastBufferedInputStream;
import it.unimi.dsi.lang.MutableString;

/**
 * Scans the database, generates images as needed and stores them back into the database.
 *
 * <P>
 * Standalone snippets are compiled and rendered as such. Otherwise, we prefix
 * {@link Constants#PREFIX} to build a reasonable bounding box.
 *
 * <p>
 * Note that we assume that lilypond is accessible through the standard path (e.g.,
 * <samp>/usr/bin</samp>).
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */
public class UpdateImages {

	private UpdateImages() {
	}

	static int exec(final String command[], final File basedir) throws IOException, InterruptedException {
		final Process process = Constants.RUNTIME.exec(command, null, basedir);
		final InputStream output = process.getInputStream(), error = process.getErrorStream();

		final Runnable outputGobbler = () -> {
			final BufferedReader br = new BufferedReader(new InputStreamReader(output));
			try {
				String line;
				while ((line = br.readLine()) != null) System.out.println(line);
				System.out.flush();
			} catch (final IOException dontCare) {
			}
		};
		outputGobbler.run();

		final Runnable errorGobbler = () -> {
			final BufferedReader br = new BufferedReader(new InputStreamReader(error));
			try {
				String line;
				while ((line = br.readLine()) != null) System.err.println(line);
				System.err.flush();
			} catch (final IOException dontCare) {
			}
		};
		errorGobbler.run();

		process.waitFor();
		return process.exitValue();
	}

	/**
	 * Updates (possibly a subset of) the database.
	 *
	 * @param ids a set of ids to restrict the update process; if empty, all items in the database are
	 *            checked.
	 * @param dbUri the JDBC URI of the database.
	 * @param lilyOpts additional options for Lilypond (usually, jailing).
	 * @param usr the user to be used to run the rest of the command suite, or the empty string for the
	 *            current user.
	 * @param tempDir the temporary directory where all files should be written, or <code>null</code>
	 *            for the default directory.
	 */

	@SuppressWarnings("deprecation")
	public static void update(final Collection<?> ids, final String dbUri, final String lilyOpts, final String usr, final File tempDir) throws SQLException, IOException, InterruptedException, InstantiationException, ClassNotFoundException, IllegalAccessException {
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		final Connection connection = DriverManager.getConnection(dbUri);

		final PreparedStatement update = connection.prepareStatement("update snippet set image=?,largeimage=?,lastupddate=?,lastupdtime=? where id=?");

		final Statement s = connection.createStatement();
		final ResultSet rs = s.executeQuery("select id,title,snippet,lastmoddate,lastmodtime,lastupddate,lastupdtime,standalone,large from snippet " + "where ( ISNULL(lastupddate) OR ISNULL(lastupdtime) OR " + "lastmoddate > lastupddate OR (lastmoddate=lastupddate AND lastmodtime > lastupdtime) )" + (ids.size() != 0 ? " AND id in (" + StringUtils.join(ids.iterator(), ',') + ")" : ""));

		final String[] command = new String[3];
		command[0] = "/bin/bash";
		command[1] = "-c";
		final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();

		while (rs.next()) {
			final int id = rs.getInt("id");
			final boolean standalone = "1".equals(rs.getString("standalone"));
			final boolean large = "1".equals(rs.getString("large"));
			System.err.println("\n*********** Updating snippet \"" + rs.getString("title") + "\" (id=" + id + ")...");

			final File lilypond = File.createTempFile("LSR" + id + "", ".ly", tempDir);
			// Note that baseDir == tempDir except when tempDir == null.
			final File baseDir = new File(lilypond.getParent());

			// Relative names for all files.
			final MutableString basename = new MutableString(lilypond.getName().toString()).replace(".ly", ""),
					png = new MutableString(basename).append(".png"),
					pngLarge = new MutableString(basename).append("-large").append(".png");

			final Writer writer = new OutputStreamWriter(new FileOutputStream(lilypond), StandardCharsets.UTF_8);

			if (!standalone) writer.write(Constants.PREFIX);
			writer.write(decoder.decode(ByteBuffer.wrap(rs.getBytes("snippet"))).toString());
			writer.close();

			// The --eps option must be there so that gs is not invoked to generate the PDF output (it will fail
			// as we're running jailed).

			String script = "( cd " + baseDir + "; ulimit -t 10; sudo /usr/bin/lilypond " + lilyOpts + " -dbackend=eps --eps -dtall-page-formats=eps -dno-use-paper-size-for-page " + lilypond.getName() + "; echo \"Lilypond return code: $?\"; " + (usr.length() > 0 ? " sudo -u " + usr + " sh -c '( " : "");

			final MutableString eps = new MutableString(basename).append(".eps");
			// ALERT: Kluge: we go for -1.eps if .eps does not exists.
			if (!new File(eps.toString()).exists()) eps.insert(basename.length(), "-1");

			if (large) script = script + "convert -density 10 +append -mattecolor black -fill white -frame 2x2+1+1 " + eps + " " + png + "; echo \"convert (1) return code: $?\"; " + "convert -density 40 +append -mattecolor black -fill white -frame 2x2+1+1 " + eps + " " + pngLarge + "; echo \"convert (2) return code: $?\"; ";
			else script += "convert -density 100 " + eps + " " + png + "; echo \"convert return code: $?\"; ";

			final File logfile = new File(baseDir, "lsr_log");
			if (logfile.exists() && !logfile.canWrite()) throw new IllegalStateException(logfile + " is not writable");
			script += (usr.length() != 0 ? " )'" : "") + " ) </dev/null >>" + logfile + " 2>>" + logfile;

			command[2] = script;
			exec(command, baseDir);

			FastBufferedInputStream blobContent = null, blobContentLarge = null;

			try {
				blobContent = new FastBufferedInputStream(new FileInputStream(new File(baseDir, png.toString())));
			} catch (final IOException conversionDidntWork) {
			}
			try {
				if (large) blobContentLarge = new FastBufferedInputStream(new FileInputStream(new File(baseDir, pngLarge.toString())));
			} catch (final IOException conversionDidntWork) {
			}

			if (blobContent != null && (!large || blobContentLarge != null)) {
				update.setBinaryStream(1, blobContent, Integer.MAX_VALUE);
				update.setBinaryStream(2, blobContentLarge, Integer.MAX_VALUE);
				update.setDate(3, new Date(System.currentTimeMillis()));
				update.setTime(4, new Time(System.currentTimeMillis()));
				update.setInt(5, id);

				update.execute();
			}

			if (blobContent != null) blobContent.close();
			if (blobContentLarge != null) blobContentLarge.close();

			lilypond.delete();
			command[2] = "rm -f " + basename + "*.tex* " + basename + "*.count " + basename + "*.eps " + basename + "*.png " + basename + ".midi </dev/null >>" + logfile + " 2>>" + logfile;
			exec(command, baseDir);
			System.err.println("*********** done.");
		}

		rs.close();
		s.close();
		connection.close();
	}

	public static void main(final String[] arg) throws SQLException, InterruptedException, IOException, InstantiationException, ClassNotFoundException, IllegalAccessException {
		update(Collections.EMPTY_SET, Constants.DB_URI, Constants.LILY_OPTS, Constants.USR, new File(Constants.TEMP_DIR));
	}
}
