package it.unimi.dsi.lsr;

/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.ccil.cowan.tagsoup.Parser;
import org.jsoup.Jsoup;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

import it.unimi.dsi.fastutil.io.FastBufferedOutputStream;
import it.unimi.dsi.lang.MutableString;

/**
 * Dumps each database record into a single file.
 *
 * <P>
 * For each record, a filename is generated using the record category (for the subdirectory) and the
 * record title. The file will contain the snippet, and the text in a comment section. Special
 * characters not allowed in filesystems are suitably escaped.
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */
public class Database2Snippets {

	private final static MutableString split(final MutableString s, final int lineLength) {
		int space, nextNewline, pos = 0;
		while (pos < s.length() - 1) {
			// System.err.println( pos + ":" + s );
			nextNewline = -1;
			boolean forceNewline = false;
			for (;;) {
				nextNewline = s.indexOf('\n', pos);
				// System.err.println( nextNewline );
				if (nextNewline == -1 || (forceNewline = nextNewline + 1 < s.length() && Character.isWhitespace(s.charAt(nextNewline + 1)))) break;
				if (nextNewline - pos < lineLength) s.replace(nextNewline, nextNewline + 1, ' ');
				else break;
			}

			if (forceNewline && nextNewline - pos <= lineLength) {
				pos = nextNewline;
				while (pos < s.length() && Character.isWhitespace(s.charAt(pos))) pos++;
				continue;
			}

			if (s.length() - pos < lineLength) break;
			space = pos + s.substring(pos, pos + lineLength).lastIndexOf(' ');
			if (space == pos - 1) space = s.indexOf(' ', pos);
			if (space == -1) break;
			s.replace(space, space + 1, '\n');
			pos = space + 1;
		}

		return s;
	}

	private static final class HTMLContentHandler implements ContentHandler {
		/** Supported HTML tags. */
		private final static String[] HTML_TAG = { "code", "samp", "emph", "q", "p", "li", "ul", "ol" };
		/** Texinfo translations for tags in {@link #HTML_TAG}. */
		private final static String[] TEXINFO_TAG_OPEN = { "@code{", "@samp{", "@emph{", "@qq{", "", "* ", "\n", "\n" };
		private final static String[] TEXINFO_TAG_CLOSE = { "}", "}", "}", "}", "\n", "\n", "", "" };

		final public MutableString text = new MutableString();

		private int skipping = 0;

		@Override
		public void startDocument() throws SAXException {
			skipping = 0;
			text.length(0);
		}

		@Override
		public void characters(final char[] ch, final int start, final int length) throws SAXException {
			if (skipping == 0) text.append(ch, start, length);
		}

		@Override
		public void endElement(final String namespaceURI, final String localName, final String qName) throws SAXException {
			if ("script".equalsIgnoreCase(localName) || "style".equalsIgnoreCase(localName)) skipping--;
			for (int i = HTML_TAG.length; i-- != 0;) if (HTML_TAG[i].equalsIgnoreCase(localName)) text.append(TEXINFO_TAG_CLOSE[i]);
		}

		@Override
		public void ignorableWhitespace(final char[] ch, final int start, final int length) throws SAXException {
			if (skipping == 0) text.append(ch, start, length);
		}

		@Override
		public void startElement(final String namespaceURI, final String localName, final String qName, final Attributes atts) throws SAXException {
			if ("script".equalsIgnoreCase(localName) || "style".equalsIgnoreCase(localName)) {
				skipping++;
				return;
			}
			for (int i = HTML_TAG.length; i-- != 0;) if (HTML_TAG[i].equalsIgnoreCase(localName)) text.append(TEXINFO_TAG_OPEN[i]);
		}

		@Override
		public void endDocument() throws SAXException {
		}

		@Override
		public void endPrefixMapping(final String prefix) throws SAXException {
		}

		@Override
		public void processingInstruction(final String target, final String data) throws SAXException {
		}

		@Override
		public void setDocumentLocator(final Locator locator) {
		}

		@Override
		public void skippedEntity(final String name) throws SAXException {
		}

		@Override
		public void startPrefixMapping(final String prefix, final String uri) throws SAXException {
		}
	}

	private Database2Snippets() {
	}

	@SuppressWarnings("deprecation")
	public static void main(final String[] arg) throws SQLException, IOException, SAXException, InstantiationException, ClassNotFoundException, IllegalAccessException {

		if (arg.length == 0) {
			System.err.println("Database2Snippets <DESTDIR> [DOCS]");
			return;
		}

		final File destDir = new File(arg[0]);
		final boolean docs = arg.length > 1;

		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		final Connection connection = DriverManager.getConnection(Constants.DB_URI);

		final Statement s = connection.createStatement();
		final ResultSet rs = s.executeQuery("select title,snippet,text,texttype," + "tag0.name as tag0,tag1.name as tag1,tag2.name as tag2,tag3.name as tag3,tag4.name as tag4,tag5.name as tag5,tag6.name as tag6 from snippet " + "left outer join tag as tag0 on id_tag0_tag=tag0.id " + "left outer join tag as tag1 on id_tag1_tag=tag1.id " + "left outer join tag as tag2 on id_tag2_tag=tag2.id " + "left outer join tag as tag3 on id_tag3_tag=tag3.id " + "left outer join tag as tag4 on id_tag4_tag=tag4.id " + "left outer join tag as tag5 on id_tag5_tag=tag5.id " + "left outer join tag as tag6 on id_tag6_tag=tag6.id " + "where approved='1' order by snippet.id");
		final Parser parser = new Parser();
		final HTMLContentHandler contentHandler = new HTMLContentHandler();
		final MutableString title = new MutableString(), text = new MutableString(), dir = new MutableString();
		// These arrays specify replacement for characters not allowed in
		// filenames.
		final char[] toBeReplaced = new char[] { ' ', '"', '*', '/', ':', '<', '>', '?', '\\', '|', '_', ';' },
				replacements = new char[] { '-', '\'', '+', '-', '-', '-', '-', '-', '-', '-', '-', '-' },
				toBeDeleted = new char[] { '(', ')', '\'' };
		final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();
		final CharsetDecoder looseDecoder = StandardCharsets.UTF_8.newDecoder();
		looseDecoder.onMalformedInput(CodingErrorAction.REPLACE);

		boolean isDocs;
		while (rs.next()) {
			isDocs = false;
			for (int i = 0; i < 7; i++) if ("docs".equals(rs.getString("tag" + i))) {
				isDocs = true;
				break;
			}

			String tag;
			for (int i = 0; i < 7 + (!docs ? 1 : 0); i++) {
				tag = i == 7 ? "all" : rs.getString("tag" + i);
				if (tag != null && (!docs || (isDocs && !"docs".equals(tag)))) {

					// Strip HTML from title
					final String nakedTitle = Jsoup.parse(decoder.decode(ByteBuffer.wrap(rs.getBytes("title"))).toString()).text();

					title.replace(nakedTitle);
					title.replace(toBeReplaced, replacements);
					title.delete(toBeDeleted);
					title.toLowerCase();

					dir.replace(tag);
					dir.replace(toBeReplaced, replacements);
					dir.delete(toBeDeleted);
					dir.toLowerCase();
					final File directory = new File(destDir, dir.toString());
					directory.mkdir();
					final File file = new File(directory, title.append(".ly").toString());

					final PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FastBufferedOutputStream(new FileOutputStream(file)), StandardCharsets.UTF_8));
					pw.println("\\version \"" + Constants.VERSION + "\"");
					pw.println();
					pw.println("\\header {");
					pw.println("  texidoc = \"");

					try {
						text.replace(decoder.decode(ByteBuffer.wrap(rs.getBytes("text"))).toString());
					} catch (final MalformedInputException e) {
						text.replace(looseDecoder.decode(ByteBuffer.wrap(rs.getBytes("text"))).toString());
						System.err.println("Malformed input in text of \"" + rs.getString("title") + "\"");
					}

					final String type = rs.getString("texttype");
					if ("T".equals(type)) text.replace(new char[] { '@', '{', '}' }, new String[] { "@@", "@{", "@}" });
					else {
						parser.setContentHandler(contentHandler);
						parser.parse(new InputSource(new StringReader(text.replace("@", "@@").replace("{", "@{").replace("}", "@}").toString())));
						text.replace(contentHandler.text);
					}

					// Escape backslashes and quotes
					text.replace("\\", "\\\\");
					text.replace("\"", "\\\"");
					split(text, 72);
					text.println(pw);
					pw.println();

					pw.println("\"");
					pw.println("  doctitle = \"" + nakedTitle.replace("\\", "\\\\").replace("\"", "\\\"") + "\"");
					pw.println("}");

					try {
						pw.println(decoder.decode(ByteBuffer.wrap(rs.getBytes("snippet"))).toString());
					} catch (final MalformedInputException e) {
						pw.println(looseDecoder.decode(ByteBuffer.wrap(rs.getBytes("snippet"))).toString());
						System.err.println("Malformed input in snippet of \"" + rs.getString("title") + "\"");
					}

					pw.close();
				}
			}
		}

		rs.close();
		s.close();
		connection.close();
	}
}
