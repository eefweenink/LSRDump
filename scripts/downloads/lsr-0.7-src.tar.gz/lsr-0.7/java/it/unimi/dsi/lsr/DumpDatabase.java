package it.unimi.dsi.lsr;

/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.ccil.cowan.tagsoup.Parser;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

import it.unimi.di.mg4j.tool.Scan;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

/**
 * Dump to standard output the content of a database column as a series of blocks of texts separated
 * by a NUL. The result can be fed to {@link Scan} using NUL as a separator.
 *
 * <P>
 * In case you provide <samp>id</samp> as a column name, a map from ordered <samp>id</samp> column
 * values to increasing integers (e.g., the map from <samp>id</samp> column values to document
 * indices) will be written to standard output.
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */
public class DumpDatabase {

	private static PrintWriter out;

	private static final class HTMLContentHandler implements ContentHandler {

		private int skipping = 0;

		@Override
		public void startDocument() throws SAXException {
			skipping = 0;
		}

		@Override
		public void characters(final char[] ch, final int start, final int length) throws SAXException {
			if (skipping == 0) out.print(new String(ch, start, length));
		}

		@Override
		public void endElement(final String namespaceURI, final String localName, final String qName) throws SAXException {
			if ("script".equalsIgnoreCase(localName) || "style".equalsIgnoreCase(localName)) skipping--;
		}

		@Override
		public void ignorableWhitespace(final char[] ch, final int start, final int length) throws SAXException {
			if (skipping == 0) out.print(new String(ch, start, length));
		}

		@Override
		public void startElement(final String namespaceURI, final String localName, final String qName, final Attributes atts) throws SAXException {
			if ("script".equalsIgnoreCase(localName) || "style".equalsIgnoreCase(localName)) skipping++;
		}

		@Override
		public void endDocument() throws SAXException {
			out.println();
		}

		@Override
		public void endPrefixMapping(final String prefix) throws SAXException {
		}

		@Override
		public void processingInstruction(final String target, final String data) throws SAXException {
		}

		@Override
		public void setDocumentLocator(final Locator locator) {
		}

		@Override
		public void skippedEntity(final String name) throws SAXException {
		}

		@Override
		public void startPrefixMapping(final String prefix, final String uri) throws SAXException {
		}
	}

	private DumpDatabase() {
	}

	@SuppressWarnings("deprecation")
	public static void main(final String[] arg) throws SQLException, SAXException, IOException, InstantiationException, ClassNotFoundException, IllegalAccessException {
		// TODO: output buffering

		if (arg.length == 0) {
			System.err.println("DumpDatabase [id|title|text|snippet]");
			return;
		}

		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		final Connection connection = DriverManager.getConnection(Constants.DB_URI);

		final Statement s = connection.createStatement();
		final ResultSet rs = s.executeQuery("select " + arg[0] + ",texttype from snippet where approved='1' order by id");
		final Parser parser = new Parser();
		final HTMLContentHandler contentHandler = new HTMLContentHandler();
		parser.setContentHandler(contentHandler);
		final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();
		final String field = arg[0];

		if (!"id".equals(field)) out = new PrintWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8));

		if ("id".equals(field)) {
			final Int2IntOpenHashMap id2pos = new Int2IntOpenHashMap();
			id2pos.defaultReturnValue(-1);
			for (int i = 0; rs.next(); i++) id2pos.put(i, rs.getInt(1));
			final ObjectOutputStream oos = new ObjectOutputStream(System.out);
			oos.writeObject(id2pos);
			oos.flush();
		} else if ("snippet".equals(field)) {
			while (rs.next()) out.print(decoder.decode(ByteBuffer.wrap(rs.getBytes(field))).toString() + (char)0);
		} else {
			while (rs.next()) {
				final String text = decoder.decode(ByteBuffer.wrap(rs.getBytes(field))).toString();
				if (field.equals("title") || "T".equals(rs.getString("texttype"))) out.println(text);
				else parser.parse(new InputSource(new StringReader(text.toString())));

				out.print((char)0);
			}
		}

		if (out != null) out.close();
		rs.close();
		s.close();
		connection.close();
	}
}
