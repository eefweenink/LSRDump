package it.unimi.dsi.lsr;

/*		 
 * Copyright (C) 2005-2022 Sebastiano Vigna 
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

/** A container for constants used throughout LSR.
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */
public class Constants {

	/** The current Lilypond version. */
	public final static String VERSION = "2.22.2";
	
	/** A prefix of Lilypond source code used to format correctly non-standalone snippets. 
	 * 
	 * <P>The value of this constant may be set using
	 * the <code>it.unimi.dsi.lsr.prefix</code> property.
	 */

	public final static String PREFIX = 
		System.getProperty( "it.unimi.dsi.lsr.prefix",
		"#(define default-toplevel-book-handler print-book-with-defaults-as-systems)\n" +
		"\n" +
		"\n" +
		"#(ly:set-option (quote no-point-and-click))\n" +
		"#(define inside-lilypond-book #t)\n" +
		"#(define version-seen #t)\n" +
		"\n" +
		"\\paper {\n" +
		"  #(define dump-extents #t)\n" + 
		"  indent = 0\\mm\n" +
		"  linewidth = 160\\mm - 2.0 * 0.4\\in\n" +
		"  ragged-right = ##t\n" +
		"}\n" +
		"\n" +
		"\\layout {}\n" );

	/** The JDBC URI used to access the database.
	 * 
	 * <P>The value of this constant may be set using
	 * the <code>it.unimi.dsi.lsr.dburi</code> property. The default
	 * value accesses a MySQL server on <samp>localhost</samp> using
	 * database name, user and password set to <samp>lsr</samp>.
	 */
	public final static String DB_URI = System.getProperty( "it.unimi.dsi.lsr.dburi", "jdbc:mysql://localhost/lsr?user=lsr&password=lsr&useLegacyDatetimeCode=false&serverTimezone=Europe/Rome&useSSL=false" );
	
	/** Additional options for Liliypond.
	 * 
	 * <P>The value of this constant may be set using
	 * the <code>it.unimi.dsi.lsr.lilyopt</code> property. The default
	 * is no option, but a typical value could be <samp>-jnobody,nobody,/mnt/jail,/tmp</samp>
	 * to run Lilypond in a jail.
	 * 
	 * <P><strong>Warning</strong>: if this option is not specified no user/group restriction
	 * will be applied to Lilypond.
	 */
	public final static String LILY_OPTS = System.getProperty( "it.unimi.dsi.lsr.lilyopts", "-jlsr,lsr,/mnt/lilyjail,/tmp" );

	/** User for command execution.
	 * 
	 * <P>The value of this constant may be set using
	 * the <code>it.unimi.dsi.lsr.usr</code> property. The default
	 * is the empty string, which amounts to using the current user.
	 * 
	 * <p>Usually this options is paired with {@link #LILY_OPTS} and {@link #TEMP_DIR} to run Lilypond
	 * in a jail with a user-writable directory, and then run the rest of the commands
	 * with the same user and the same directory.
	 */
	public final static String USR = System.getProperty( "it.unimi.dsi.lsr.usr", "lsr" );

	/** Temporary directory for command execution.
	 * 
	 * <P>The value of this constant may be set using
	 * the <code>it.unimi.dsi.lsr.tempdir</code> property. The default
	 * is <samp>/tmp</samp>.
	 * 
	 * <p>Usually this options is paired with {@link #LILY_OPTS} and {@link #USR} to run Lilypond
	 * in a jail with a user-writable directory, and then run the rest of the commands
	 * with the same user and the same directory.
	 */
	public final static String TEMP_DIR = System.getProperty( "it.unimi.dsi.lsr.tempdir", "/mnt/lilyjail/tmp" );

	public final static Runtime RUNTIME = Runtime.getRuntime();

	private Constants() {}
}
