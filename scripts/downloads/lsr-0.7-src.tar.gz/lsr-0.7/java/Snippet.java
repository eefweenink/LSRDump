/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Returns the content of the snippet identified by the parameter <code>id</code>.
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */
public class Snippet extends LsrServlet {
	private static final long serialVersionUID = 1L;
	private final static int BUFFER_SIZE = 2048;

	@Override
	public void doGet(final HttpServletRequest request, final HttpServletResponse response) throws IOException {
		if (request.getParameter("id") == null) return;
		final int id = Integer.parseInt(request.getParameter("id"));

		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		final OutputStream output = response.getOutputStream();

		try {
			final Connection connection = DriverManager.getConnection((String)getServletContext().getAttribute("dburi"));
			final Statement s = connection.createStatement();
			final ResultSet rs = s.executeQuery("select snippet from snippet where id=" + id);
			rs.next();
			// This is UTF-8, and we know it.
			final InputStream inputStream = rs.getBinaryStream(1);

			if (request.getParameter("comp") != null) {
				final OutputStreamWriter osw = new OutputStreamWriter(output, StandardCharsets.UTF_8);
				osw.write((String)getServletContext().getAttribute("PREFIX"));
				osw.flush();
			}

			System.err.println(getServletContext().getAttribute("PREFIX"));

			final byte[] buffer = new byte[BUFFER_SIZE];
			int l;
			while ((l = inputStream.read(buffer)) > 0) output.write(buffer, 0, l);

			output.flush();
			rs.close();
			s.close();
			connection.close();

		} catch (final SQLException e) {
			throw new IOException(e.toString());
		}

	}
}
