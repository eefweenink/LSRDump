/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

/**
 * An instance of this class is used to pack the results gathered by {@link BrowsePage} in such a
 * way that they are easily accessible from the Velocity Template Language.
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */

public class BrowseItem {
	/** The SQL id of this result. */
	public final int id;
	/** The (possibly marked) title. */
	public String title;
	/** The marked text. */
	public String text;
	/** A non-marked version of the title (for IMG ALT attributes). */
	public String alt;

	public BrowseItem(final int id) {
		this.id = id;
	}

	public int id() {
		return id;
	}

	public String text() {
		return text;
	}

	public void text(final String text) {
		this.text = text;
	}

	public String title() {
		return title;
	}

	public void title(final String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "[id: " + id + " title: " + title + "]";
	}

	public final String alt() {
		return alt;
	}
}
