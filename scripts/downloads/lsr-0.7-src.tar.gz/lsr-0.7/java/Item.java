/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.jsoup.Jsoup;

import it.unimi.dsi.fastutil.ints.IntSets;
import it.unimi.dsi.lsr.UpdateImages;

/**
 * Displays fully an item (using <samp>item.vm</samp>).
 *
 * <p>
 * This servlet uses the configuration parameters <samp>dburi</samp>, <samp>tempdir</samp>,
 * <samp>usr</samp> and <samp>lilyopts</samp>, as it has to call
 * {@link it.unimi.dsi.lsr.UpdateImages#update(Collection, String, String, String, File)}.
 *
 * @author Sebastiano Vigna
 * @since 0.1
 */
public class Item extends LsrServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * The name of the columns that will be fetched and passed to the VTL context. <strong>Must</strong>
	 * be in sync with {@link #COLUMNS_SQL}.
	 */
	private final static String COLUMN[] = { "id", "title", "text", "large" };

	/** The column part of the SQL query. <strong>Must</strong> be in sync with {@link #COLUMN}. */
	private final static String COLUMNS_SQL = "id,title,text,large";

	@Override
	public Template handleRequest(final HttpServletRequest request, final HttpServletResponse response, final Context context) throws IOException {
		Template template = null;

		try {
			if (request.getParameter("id") == null) return null;
			final int id = Integer.parseInt(request.getParameter("id"));

			final File tempDir = (String)getServletContext().getAttribute("tempdir") != null ? new File((String)getServletContext().getAttribute("tempdir")) : null;
			if (request.getParameter("u") != null) UpdateImages.update(IntSets.singleton(id), (String)getServletContext().getAttribute("dburi"), (String)getServletContext().getAttribute("lilyopts"), (String)getServletContext().getAttribute("usr"), tempDir);

			final Connection connection = DriverManager.getConnection((String)getServletContext().getAttribute("dburi"));

			final Statement s = connection.createStatement();
			final ResultSet rs = s.executeQuery("select " + COLUMNS_SQL + " from snippet where id=" + id);

			if (!rs.next()) {
				System.err.println("No results for query with id " + id);
				return null;
			}

			final CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();
			for (final String element : COLUMN) context.put(element, decoder.decode(ByteBuffer.wrap(rs.getBytes(element))).toString());
			// Stripped of HTML tags
			context.put("nakedTitle", Jsoup.parse(decoder.decode(ByteBuffer.wrap(rs.getBytes("title"))).toString()).text());

			rs.close();
			s.close();
			connection.close();
			template = getTemplate("item.vm");
		} catch (final Exception e) {
			e.printStackTrace(System.err);
		}

		return template;
	}
}
