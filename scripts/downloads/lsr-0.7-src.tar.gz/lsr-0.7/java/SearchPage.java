/*
 * Copyright (C) 2005-2022 Sebastiano Vigna
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.function.Function;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.ExtendedProperties;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.velocity.Template;
import org.apache.velocity.context.Context;

import it.unimi.di.mg4j.index.DowncaseTermProcessor;
import it.unimi.di.mg4j.index.Index;
import it.unimi.di.mg4j.index.TermProcessor;
import it.unimi.di.mg4j.query.IntervalSelector;
import it.unimi.di.mg4j.query.QueryEngine;
import it.unimi.di.mg4j.query.QueryServlet;
import it.unimi.di.mg4j.query.parser.SimpleParser;
import it.unimi.di.mg4j.search.DocumentIteratorBuilderVisitor;
import it.unimi.di.mg4j.search.score.Scorer;
import it.unimi.di.mg4j.search.score.VignaScorer;
import it.unimi.dsi.fastutil.io.BinIO;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2DoubleOpenHashMap;

/**
 * The main servlet for LSR.
 *
 * <P>
 * This servlet analyses the user query and dispatch the correct template. It accepts two
 * configuration parameters, <samp>datadir</samp> (relative to the servlet deployment directory),
 * which should contain all MG4J-generated material, and <samp>dburi</samp>, which specifies the
 * database URI (the default being {@link it.unimi.dsi.lsr.Constants#DB_URI}).
 */
public class SearchPage extends QueryServlet {
	private static final long serialVersionUID = 1L;

	/** Official index names throughout LSR. */
	public final static String[] INDEX = { "text", "title", "snippet", "tag" };
	/** An array parallel to {@link #INDEX}, containing index weights. */
	public final static double[] WEIGHT = { 1, 2, 1, 3 };

	private static final Function<String, String> UNESCAPE_HTML = t -> StringEscapeUtils.unescapeHtml4(t);

	/**
	 * We overwrite this method because Velocity's concept of "current directory" is the directory where
	 * you started Tomcat. Go figure.
	 */

	@Override
	protected ExtendedProperties loadConfiguration(final ServletConfig config) throws FileNotFoundException, IOException {
		final ExtendedProperties p = super.loadConfiguration(config);
		return LsrServlet.loadConfiguration(this, p);
	}

	@Override
	public void init() throws ServletException {
		LsrServlet.init(this);

		final String datadir = getServletContext().getRealPath(getServletConfig().getInitParameter("datadir"));

		// Load all indices and put them in the name2index map.
		final Object2ReferenceOpenHashMap<String, Index> name2index = new Object2ReferenceOpenHashMap<>(INDEX.length, .5f);

		final ServletContext context = getServletContext();

		try {
			context.setAttribute("collection", BinIO.loadObject(new File(datadir, "lsr.collection").toString()));

			for (final String element : INDEX) {
				final Index index = Index.getInstance(new File(datadir, "lsr-" + element).toString(), true, true);
				name2index.put(element, index);
			}

			context.setAttribute("name2index", name2index);

			final QueryEngine queryEngine = new QueryEngine(new SimpleParser(name2index.keySet(), "text", new Object2ObjectOpenHashMap<>(new String[] {
					"text", "title", "snippet", "tag" }, new TermProcessor[] { DowncaseTermProcessor.getInstance(),
							DowncaseTermProcessor.getInstance(), DowncaseTermProcessor.getInstance(),
							DowncaseTermProcessor.getInstance() })), new DocumentIteratorBuilderVisitor(name2index, name2index.get(INDEX[0]), Integer.MAX_VALUE), name2index);

			queryEngine.score(new Scorer[] { new VignaScorer() }, new double[] { 1 });
			// queryEngine.equalize( 1000 );
			final Reference2DoubleOpenHashMap<Index> index2weight = new Reference2DoubleOpenHashMap<>(INDEX.length, .5f);
			for (int i = 0; i < INDEX.length; i++) index2weight.put(name2index.get(INDEX[i]), WEIGHT[i]);
			queryEngine.setWeights(index2weight);
			queryEngine.multiplex = true;
			queryEngine.intervalSelector = new IntervalSelector(3, 20);

			context.setAttribute("queryEngine", queryEngine);
			context.setAttribute("unescapeHtml", UNESCAPE_HTML);
			context.setAttribute("mimeType", "text/html");
		} catch (final Exception e) {
			throw new ServletException(e);
		}

		super.init();
	}

	@Override
	public Template handleRequest(final HttpServletRequest request, final HttpServletResponse response, final Context context) {
		if (request.getParameter("q") == null) try {
			return getTemplate("query.vm");
		} catch (final Exception e) {
			e.printStackTrace(System.err);
		}
		final Template template = super.handleRequest(request, response, context);
		// We pass the collection to our template so that it can substitute document pointers with SQL ids.
		context.put("collection", documentCollection);
		return template;
	}
}
