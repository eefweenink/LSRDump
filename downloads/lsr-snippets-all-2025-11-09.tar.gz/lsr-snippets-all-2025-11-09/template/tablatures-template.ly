\version "2.22.2"

\header {
  texidoc = "
Here is a simple template for fretted strings instruments.

"
  doctitle = "Tablatures template"
}
%% http://lsr.di.unimi.it/LSR/Item?id=634

upper= \relative c' {
  c4. g4 g  c
}

lower= \relative c {
  c4 e g, e'
}

\score {
  \new StaffGroup <<
    \new Staff = "guitar" <<
      \context Voice = "upper guitar" { \clef "G_8" \voiceOne \upper }
      \context Voice = "lower guitar" { \clef "G_8" \voiceTwo \lower }
    >>
    \new TabStaff = "tab" <<
      \context TabVoice = "upper tab" { \clef "moderntab" \voiceOne \upper }
      \context TabVoice = "lower tab" { \clef "moderntab" \voiceTwo \lower }
    >>
  >>
}



