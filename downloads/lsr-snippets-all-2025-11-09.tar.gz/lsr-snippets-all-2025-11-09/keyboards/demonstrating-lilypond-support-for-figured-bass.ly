\version "2.22.2"

\header {
  texidoc = "
This snippet demonstrates how figured bass is supported in LilyPond. 
In addition to the numerous BassFigure objects available, you can
always use text markups instead to get precisely what you need. All of
these examples are to be found in the relevant sections of the Notation
Reference, where you will learn how to add a figured bass with simple
but powerful notation.

"
  doctitle = "Demonstrating LilyPond support for figured bass"
}
%% http://lsr.di.unimi.it/LSR/Item?id=291


<<
  \new Voice {
    \clef bass
    dis4 c d ais
    g fis e a
    r gis d b,
    f,! e c c
    c1
  }
  \figures {
    < 6 >4 < 7\+ >8 < 6+ [_!] >
    < 6 >4 <6 5 [3+] >
    < _ >4 < 6 5/>4
    <4- 6+ 7!> <5++> <3--> <7/> r <6\+ 5/> 
    < [4 6] 8 [_! 12] >
    < 5 \markup { \tiny \number 6 \super (1) } >
    \set useBassFigureExtenders = ##t
    <4 6> <3 6> <3 7>
  }
>>



