\version "2.22.2"

\header {
  texidoc = "
Cross-staff beams may not look always good; this snippet demonstrates
how to get better results.

"
  doctitle = "Making cross-staff beams look better"
}
%% http://lsr.di.unimi.it/LSR/Item?id=508


\score {
  \new PianoStaff <<
   \new Staff = "RH" { \clef treble \time 3/4 s2.*2 }
   \new Staff = "LH" { \clef bass   \time 3/4 s2.*2 }
   \context Staff = LH
    \relative c' {
     \stemDown % Change into \stemUp to fix the bug
     c,8 [ g'
     \change Staff = RH
     d' a' e' b' ]
     % This makes the second beam look much better.
     \override Beam.concaveness = #0
     b [ e, a, d,
     \change Staff = LH
     g, c, ]
   }
  >>
}

% Prevent bad cropping.
\markup \null

\paper { tagline = ##f }

