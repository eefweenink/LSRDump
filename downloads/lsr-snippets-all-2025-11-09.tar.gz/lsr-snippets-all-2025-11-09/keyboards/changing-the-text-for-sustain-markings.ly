\version "2.22.2"

\header {
  texidoc = "
@code{Staff.pedalSustainStrings} can be used to set the text used for
pedal down and up.  Note that the only valid strings are those found in
the list of pedal glyphs - the values used this snippet constitute an
exhaustive list.

"
  doctitle = "Changing the text for sustain markings"
}
sustainNotes = { c4\sustainOn d e\sustainOff\sustainOn f\sustainOff }

\relative c' {
  \sustainNotes 
  \set Staff.pedalSustainStrings = #'("P" "P-" "-")
  \sustainNotes 
  \set Staff.pedalSustainStrings = #'("d" "de" "e")
  \sustainNotes 
  \set Staff.pedalSustainStrings = #'("M" "M-" "-")
  \sustainNotes 
  \set Staff.pedalSustainStrings = #'("Ped" "*Ped" "*")
  \sustainNotes 
}



