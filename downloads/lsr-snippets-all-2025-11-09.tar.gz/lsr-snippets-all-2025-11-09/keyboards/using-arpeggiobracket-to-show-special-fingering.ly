\version "2.22.2"

\header {
  texidoc = "
A common use of @code{arpeggioBracket} in piano music is to show that
two keys are to be played with the same finger/thumb. This requires the
use of transparent notes in another voice.

"
  doctitle = "Using arpeggioBracket to show special fingering"
}
%% http://lsr.di.unimi.it/LSR/Item?id=442

\score {
  \new Staff << 
  \new Voice \relative c' {
    \time 2/4
    <c d g b d>2
  }
  \new Voice \relative c' {
    \hideNotes
    \arpeggioBracket
    \once \override NoteColumn.ignore-collision = ##t
    <c d>2\arpeggio
  }
  >>
  \layout { ragged-right = ##t }
}



