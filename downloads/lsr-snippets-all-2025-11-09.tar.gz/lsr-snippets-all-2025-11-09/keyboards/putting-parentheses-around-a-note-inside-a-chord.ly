\version "2.22.2"

\header {
  texidoc = "
As children do not always have hands large enough, say, to plays
octavas when studying piano, or anything else, it can be useful to add
parentheses around a low note for example. In this snippet, the
@qq{parenthesized} note is made a bit smaller using the @code{\\tweak}
command on the @code{#'font-size property}.

"
  doctitle = "Putting parentheses around a note inside a chord"
}
%% http://lsr.di.unimi.it/LSR/Item?id=283


{ 
  \clef bass
  < f \parenthesize \tweak font-size #-1 f, >2
}



