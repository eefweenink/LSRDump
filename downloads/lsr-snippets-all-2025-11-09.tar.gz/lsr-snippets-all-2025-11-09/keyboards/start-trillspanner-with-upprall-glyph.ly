\version "2.22.2"

\header {
  texidoc = "
Adds an upprall glyph to the beginning of a trillspanner. 

"
  doctitle = "Start TrillSpanner with UpPrall glyph"
}
%- Start a Trill Spanner with UpPrall
%- Solution by Pierre Perol-Schneider
%- LSR snippet by Javier Ruiz-Alma 2/6/2015

\relative c'' {
  \time 2/4
  \override TrillSpanner.bound-details.left.text = 
    \markup \concat { 
      \raise #1.0 
      \smaller 
      \musicglyph "scripts.upprall" 
      \hspace #-0.6
    }
  c2\startTrillSpan ~ c ~ c\stopTrillSpan
}


