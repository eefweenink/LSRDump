\version "2.22.2"

\header {
  texidoc = "
Here is a way to display pedal brackets with a slanted line
(indicating, for example, that the sustain pedal must be gradually
released). The first bracket shows the default behaviour.

"
  doctitle = "Pedal brackets with slanted lines"
}
%% http://lsr.di.unimi.it/LSR/Item?id=698

%LSR contributed by Mats Bengtsson http://lists.gnu.org/archive/html/lilypond-devel/2008-09/msg00243.html

\relative c'' {
  \set Staff.pedalSustainStyle = #'bracket
  c1\sustainOn c \sustainOff \sustainOn c\sustainOff c
  \override Staff.PianoPedalBracket.bracket-flare = #'(1 . 6)
  c1\sustainOn c \sustainOff \sustainOn c\sustainOff c
}



