\version "2.22.2"

\header {
  texidoc = "
In a score where you've printed many chords with @code{\\arpeggio}
signs, you may want to tell the player that one particular chord must
not be arpeggiated. This can be done quite easily by adding a square
bracket instead of the arpeggio sign.

"
  doctitle = "Arpeggio bracket"
}
%% http://lsr.di.unimi.it/LSR/Item?id=237

\relative c'' {
  \arpeggioBracket
  <fis, d a>\arpeggio
}



