\version "2.22.2"

\header {
  texidoc = "
This snippet removes the first brace from a @code{PianoStaff} or a
@code{GrandStaff}, together with the clefs. It may be useful when
cutting and pasting the engraved image into existing music.

It uses @code{\\alterBroken}. 

"
  doctitle = "Removing brace on first line of piano score"
}
someMusic =  {
  \once \override Staff.Clef.stencil = ##f
  \once \override Staff.TimeSignature.stencil = ##f
  \repeat unfold 3 c1 \break
  \repeat unfold 5 c1 \break
  \repeat unfold 5 c1 
}

\score {
  \new PianoStaff
  <<
    \new Staff = "right" \relative c'' \someMusic
    \new Staff = "left" \relative c' { \clef F \someMusic }
  >>
  \layout {
    indent=75
    \context {
      \PianoStaff
      \alterBroken transparent #'(#t) SystemStartBrace
    }
  }
}

\paper { tagline = ##f }



