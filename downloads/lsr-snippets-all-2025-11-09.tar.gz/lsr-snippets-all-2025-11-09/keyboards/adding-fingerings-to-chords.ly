\version "2.22.2"

\header {
  texidoc = "
Fingerings for chords can be obtained by adding them to individual
pitches.

"
  doctitle = "Adding fingerings to chords"
}
%% http://lsr.di.unimi.it/LSR/Item?id=416

\paper { tagline = ##f }

\relative c'{
  < c-1 e-2 g-3 b-5 >2
  < d-1 f-2 a-3 c-5 >
}




