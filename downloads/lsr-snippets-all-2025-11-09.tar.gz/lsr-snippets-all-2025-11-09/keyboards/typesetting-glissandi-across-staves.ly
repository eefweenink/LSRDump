\version "2.22.2"

\header {
  texidoc = "
If you need to notate a glissando going across staves, it is very
simple to do so with LilyPond's voice-change functions.

"
  doctitle = "Typesetting glissandi across staves"
}
%% http://lsr.di.unimi.it/LSR/Item?id=742

staffPiano = \new PianoStaff {
  \time 3/4
  <<
    \context Staff = "RH" {
      \clef treble
      \relative c' {
         c4 r4 \skip 4
      }
    }

    \context Staff = "LH" {
      \clef bass
      \relative c {
        \override VoiceFollower.style = #'zigzag 
        g2
        \showStaffSwitch
        \change Staff = "RH"
        <b'' d>4
        \hideStaffSwitch
        \change Staff = "LH"
      }
    }
  >>
}

\score {
  <<
    \staffPiano
  >>
}



