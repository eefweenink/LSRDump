\version "2.22.2"

\header {
  texidoc = "
To create a piano music sheet with blank staves, use a Piano template,
generate empty measures then remove the @code{Bar_number_engraver} from
the @code{Score} context, and the @code{Time_signature_engraver},
(optionally the @code{Clef_engraver}) and @code{Bar_engraver} from the
@code{Staff} context. 

"
  doctitle = "Creating music sheet with blank piano staves"
}
%% http://lsr.di.unimi.it/LSR/Item?id=663


\score {
  \new PianoStaff <<
      \new Staff { 
        \repeat unfold 8 { s1 \break } }
      \new Staff { \clef bass \repeat unfold 8 { s1 \break } }
    >>
  \layout {
    indent = 0\in
    \context {
      \Staff
      \remove "Time_signature_engraver"
      %\remove "Clef_engraver"
      \remove "Bar_engraver"
    }
    \context {
      \Score
      \remove "Bar_number_engraver"
    }
  }
}

\paper {
  ragged-last-bottom = ##f
  line-width = 7.5\in
  left-margin = 0.5\in
  bottom-margin = 0.25\in
  top-margin = 0.25\in
}



