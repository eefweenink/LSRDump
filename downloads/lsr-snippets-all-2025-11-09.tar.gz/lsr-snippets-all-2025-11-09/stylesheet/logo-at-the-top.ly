\version "2.22.2"

\header {
  texidoc = "
Put a logo at the top left on all pages and titling.

"
  doctitle = "logo at the top"
}
%titrage avec logo en haut à gauche sur toutes les pages
%titling with logo top left on all pages 

logo = \markup { \fontsize #14 "LG" }

\paper {
  bookTitleMarkup = \markup \null
  oddHeaderMarkup = \markup {
    \override #'(baseline-skip . 3.5) \fill-line {
      \logo
    % \if \on-first-page  %version 2.23.4
       \if \on-first-page-of-part % version 2.23.3 
    %  \raise #8 \fromproperty #'header:dedication % to ajust and uncomment for dedication
    %  \if \on-first-page %version 2.23.4
      \if \on-first-page-of-part % version 2.23.3
      \raise #4 % to ajust
      \column {
        \fill-line {
          \huge \larger \larger \bold
          \fromproperty #'header:title
        }
        \fill-line {
          \large \bold
          \fromproperty #'header:subtitle
        }
        \fill-line {
          \smaller \bold
          \fromproperty #'header:subsubtitle
        }
        \fill-line {
          \fromproperty #'header:poet
          { \large \bold \fromproperty #'header:instrument }
          \fromproperty #'header:composer
        }
        \fill-line {
          \fromproperty #'header:meter
          \fromproperty #'header:arranger
        }
      }
    }
    \raise #5
  %  \if \should-print-page-number %version 2.23.4
     \if \should-print-page-number  %version 2.23.3
    \fromproperty #'page:page-number-string
  }
  evenHeaderMarkup = \oddHeaderMarkup

  %----- 
  ragged-bottom = ##t
  print-page-number = ##t
  print-first-page-number = ##f
  %top-margin = #10
}


\header {
  dedication = "à léon"
  title = "le titre"
  subtitle = "sous-titre"
  subsubtitle ="sous-sous-titre"
  instrument ="Instrument"
  composer ="The composer"
  arranger = "harmonisation"
  poet = "Poésie"
  meter  = "Legato"
  copyright = ##f %"Interpréter de préférence avant la date inscrite sous la partition"
  tagline = ##f %"Les plus belles partitions sont écritent avec LilyPond" % ##f
}

\score {
\relative c'{
  \repeat unfold 3 { c1  g' bes \pageBreak }
}
\layout { }
}



