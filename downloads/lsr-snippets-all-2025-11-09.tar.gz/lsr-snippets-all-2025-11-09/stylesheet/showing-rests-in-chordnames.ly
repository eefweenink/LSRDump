\version "2.22.2"

\header {
  texidoc = "
Here is how to show rests in the ChordNames context.

"
  doctitle = "Showing rests in ChordNames"
}
%% http://lsr.di.unimi.it/LSR/Item?id=529

%LSR modified by P.P.Schneider on Feb. 2014
%LSR modified by W. Lemberg in Feb. 2023 to avoid vertical cropping

%LSR This snippet was provided by James Bailey for version "2.17.97"

\layout {
  \context {
    \type "Engraver_group"
    \name ChordNamesRests
    \description "Typesets chord names."

    \consists "Output_property_engraver"
    \consists "Separating_line_group_engraver"
    \consists Chord_name_engraver \consists Current_chord_text_engraver

    \consists "Rest_engraver"

    noChordSymbol = ##f

    \override VerticalAxisGroup.staff-staff-spacing = #'((padding . 1))
    \override VerticalAxisGroup.remove-first = ##t
    \override VerticalAxisGroup.remove-empty = ##t
  }

  \context {
    \Score
    \accepts ChordNamesRests
  }
}

music = {
  c d e d
  f r g r
  c,1
}

\score {
  <<
    \new ChordNamesRests {
      \chordmode {
        \override Rest.Y-offset = #1
        \music
      }
    }
    \relative c' { \music }
  >>
}

