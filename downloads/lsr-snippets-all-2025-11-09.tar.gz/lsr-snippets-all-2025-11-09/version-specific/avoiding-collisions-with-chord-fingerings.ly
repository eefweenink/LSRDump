\version "2.22.2"

\header {
  texidoc = "
Fingerings and string numbers applied to individual notes will
automatically avoid beams and stems, but this is not true by default
for fingerings and string numbers applied to the individual notes of
chords.  The following example shows how this default behavior can be
overridden.

"
  doctitle = "Avoiding collisions with chord fingerings"
}
%%%LSR This has been fixed in 2.21.2 -- see Issue 1250 -vv

\relative c' {
  \set fingeringOrientations = #'(up)
  \set stringNumberOrientations = #'(up)
  \set strokeFingerOrientations = #'(up)

  % Default behavior
  r8
  <f c'-5>8
  <f c'\5>8
  <f c'-\rightHandFinger #2 >8

  % No tweak needed
  r8
  <f c'-5>8
  <f c'\5>8
   % Corrected to avoid collisions
  \override StrokeFinger.add-stem-support = ##t
  <f c'-\rightHandFinger #2 >8
}



