\version "2.22.2"

\header {
  texidoc = "
@code{\\thumb} does not behave like other fingerings, in particular
with regards to slur avoidance, since it is defined as a @code{Script}
object.  This can be changed by redefining @code{\\thumb} as a
@code{Fingering} object, which also allows finer control over
positioning with @code{fingeringOrientations}.

"
  doctitle = "Making \\thumb behave like other fingerings"
}
%% http://lsr.di.unimi.it/LSR/Item?id=690

%LSR Slur avoidance was fixed in version 2_13_24

thumb = 
\tweak 
  text 
  \markup \fontsize #5 \musicglyph  "scripts.thumb" 
  #(make-music 'FingeringEvent)

\relative c' {
  c2\thumb
  \set fingeringOrientations = #'(right)
  <c\thumb>2
}



