\version "2.22.2"

\header {
  texidoc = "
Sometimes, a dotted chord may contain the same note twice, in which
case two augmentation dots will be printed (accordingly to recommended
engraving practice).  Here is how to prevent this behavior from
appearing, in cases where it would be unwanted.

"
  doctitle = "Preventing double augmentation dots with identical notes in chords"
}
{
  %% Only available since 2.19.0
  <d' d'>4.
  \once \override Staff.DotColumn.chord-dots-limit = #1
  <d' d'> c'4
}


