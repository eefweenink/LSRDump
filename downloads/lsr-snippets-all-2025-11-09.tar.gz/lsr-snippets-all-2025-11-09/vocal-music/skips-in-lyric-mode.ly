\version "2.22.2"

\header {
  texidoc = "
The @code{s} syntax for skips is only available in note mode and chord
mode. In other situations, for example, when entering lyrics, using the
@code{\\skip} command is recommended. 

"
  doctitle = "Skips in lyric mode"
}
<<
  \relative c'' { a1 | a }
  \new Lyrics \lyricmode { \skip 1 bla1 }
>>



