\version "2.22.2"

\header {
  texidoc = "
 For joining syllables, LilyPond doesn't use the hyphen of the text
font but instead draws a simple line with variable length. Its standard
vertical position doesn't always fit the proportions of the text font.
When using a font with a large x-height, it may be too low.




You can adjust the vertical positioning of the hyphens manually. To get
a good result you may want to insert a “real” hyphen for comparision
(the l-e in the snippet).




"
  doctitle = "Adjusting vertical positioning of lyric hyphens"
}
%% http://lsr.di.unimi.it/LSR/Item?id=793

% Hannes Kuhnert <hannes.kuhnert@gmx.de>
% contributed to LilyPond Snippet Repository <http://lsr.di.unimi.it/>
% 1.2.2012

\score {
  <<
    \context Voice="Lied" {
      \relative c' {
        \clef G
        \key c \major
        e2 d c1
      }
    }

    \context Lyrics="Lied" {
      \lyricsto Lied {
        La -- l-e -- lu.
      }
    }
  >>

  \layout {
    \context {
      \Lyrics
      \override LyricHyphen.Y-offset = #0.16
    }
  }
}

\paper {
  #(define fonts
    (make-pango-font-tree
      "Serif"
      "Sans"
      "Monospace"
      (/ 20 20)
    )
  )
}



