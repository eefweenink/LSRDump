\version "2.22.2"

\header {
  texidoc = "
By default, lyrics syllables that start a melisma are left aligned on
their note.  The alignment can be altered using the
@code{lyricMelismaAlignment} property.

"
  doctitle = "Aligning syllables with melisma"
}
\score {
  <<
    \new Staff {
      \relative c'' 
      \new Voice = "vocal" {
        c d~^\markup default  d e
        c d~^\markup "right aligned" d e
        c d~^\markup "center aligned" d e
        c d~^\markup "reset to default" d e
      }
    }
    \new Lyrics \lyricsto "vocal" { 
      word word word 
      \set lyricMelismaAlignment = #RIGHT 
      word word word 
      \set lyricMelismaAlignment = #CENTER 
      word word word 
      \unset lyricMelismaAlignment
      word word word 
    }
  >>
}



