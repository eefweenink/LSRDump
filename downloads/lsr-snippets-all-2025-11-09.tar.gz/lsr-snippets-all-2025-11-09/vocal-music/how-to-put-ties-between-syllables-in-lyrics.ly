\version "2.22.2"

\header {
  texidoc = "
This can be achieved by separating those syllables by tildes.  

"
  doctitle = "How to put ties between syllables in lyrics"
}
\lyrics {
  wa~o~a 
}



