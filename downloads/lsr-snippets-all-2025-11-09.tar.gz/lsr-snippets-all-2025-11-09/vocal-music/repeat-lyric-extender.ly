\version "2.22.2"

\header {
  texidoc = "
A lyric extender which extends into several @code{\\alternative} blocks
can be simulated by adding a 'null' markup before the extender.

"
  doctitle = "Repeat lyric extender"
}
%% => http://www.lilypondforum.de/index.php?topic=1123.msg6177#msg6177
%% => http://lilypond.1069038.n5.nabble.com/Text-extender-in-repeat-td177410.html
%% Added by PPS on June 2015

\score { 
  <<
    \new Staff \relative c'' { 
      \time 2/1
      \repeat volta 2 {
        r4 g4 d'2. a4 bes2~
        bes  a2 g1~
      }
      \alternative{
       { g2 fis4 e fis1 d'1 c2 bes}
       { g\repeatTie fis4 e fis1 }
      }
      \bar "|."
    }
    \addlyrics {
       of Prin- ces all __ _ _ the __  _ 
       %% put some space here:
       \once\override LyricText.self-alignment-X = #-0.7 
       flow’r.
       Who took a-
       %% volta 2
       \tweak self-alignment-X #-3 \markup \null __ 
       the __ _ 
       %% put some space here:
       \once\override LyricText.self-alignment-X = #-0.7 
       flow’r.
    }
  >>
}


