\version "2.22.2"

\header {
  texidoc = "
Markup mode may be used to format individual syllables in lyrics.

"
  doctitle = "Formatting lyrics syllables"
}
%LSR Tip taken from http://lists.gnu.org/archive/html/lilypond-user/2007-12/msg00215.html

mel = \relative c'' { c4 c c c c1 }
lyr = \lyricmode {
  Your lyrics \markup { \italic can } \markup { \with-color #red contain }
  \markup { \fontsize #8 \bold Markup! }
}

<<
  \new Voice = melody \mel
  \new Lyrics \lyricsto melody \lyr
>>



