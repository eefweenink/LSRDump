\version "2.22.2"

\header {
  texidoc = "
To create a song sheet with only chord symbols and lyrics, it is not
recommended to use Lilypond but to use a tool specifically designed for
the task such as GuitarTeX.  There are ways to make Lilypond produce
such output, however.  One approach is to use the @code{\\Devnull}
context. 

"
  doctitle = "Chord Names and Lyrics without a Staff"
}
%% http://lsr.di.unimi.it/LSR/Item?id=536


text = \lyricmode { Ho ho, ho ho ho. Ha ha, ha. }

nullMelody = \relative c'' {
  e4 e e2
  e2 e
  \tuplet 3/2 { d2 c d }
}

harmonies = \chordmode { a1:m | d:m | e:7 | }

\score {
  <<
    \new ChordNames
      \with { \override VerticalAxisGroup.staff-affinity = ##f }
      \harmonies
      
    \new Devnull = "vocal" 
      \nullMelody
      
    \new Lyrics 
      \with { \override LyricText.self-alignment-X = #LEFT }
      \lyricsto "vocal" \text
  >>
  \layout { }
}



