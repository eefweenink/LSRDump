\version "2.22.2"

\header {
  texidoc = "
If you use non vocal letters in lyrics which come in combination with a
word but the letters don't come under the tone but just left of the
word you can shift the whole phrase to the left.

"
  doctitle = "Shifting lyrics when using non vocal letters"
}
%% http://lsr.di.unimi.it/LSR/Item?id=737

left = { \once \override LyricText.X-offset = #-2.8 }

\relative c' { 
  c4 c d8 g e4 
}

\addlyrics { 
  \left "S to" -- bom pu -- tu -- jem 
}



