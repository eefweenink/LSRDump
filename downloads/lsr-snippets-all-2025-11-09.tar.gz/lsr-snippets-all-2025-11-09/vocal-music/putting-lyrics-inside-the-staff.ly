\version "2.22.2"

\header {
  texidoc = "
Lyrics can be moved vertically to place them inside the staff.  The
lyrics are moved with @code{\\override LyricText.extra-offset = #'(0 .
dy)} and there are similar commands to move the extenders and hyphens. 
The offset needed is established with trial and error.

"
  doctitle = "Putting lyrics inside the staff"
}
% LSR : contributed by Jan-Peter Voigt http://lists.gnu.org/archive/html/lilypond-user/2010-10/msg00451.html

<<
  \new Staff <<
    \new Voice = "voc" \relative c' { \stemDown a bes c8 b c4 }
  >>
  \new Lyrics \with {
    \override LyricText.extra-offset = #'(0 . 8.6)
    \override LyricExtender.extra-offset = #'(0 . 8.6)
    \override LyricHyphen.extra-offset = #'(0 . 8.6)
  } \lyricsto "voc" { La la -- la __ _ la }
>>



