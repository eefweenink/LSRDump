\version "2.22.2"

\header {
  texidoc = "
If a vocal part contains many short note values and melismata, and
melismata are shown by both beams and slurs, there are many instances
of @code{ d([ b)] } for example. To save tedious keystrokes, it’s very
convenient to redefine [ and ] so they provoke both the beam and the
slur. Alternatively, the slurs may be omitted as in the second example,
to avoid misinterpretations (performers might take the slur as an
indication for dynamics and articulation, even if it’s only intended to
provide information on melismata) or to get a clearer, less crowded
look.

"
  doctitle = "Combining beam and slur in one keystroke"
}
\paper { tagline = ##f }

"[" =
- #(make-music
    'SlurEvent
    'span-direction
    -1)
- #(make-music
    'BeamEvent
    'span-direction
    -1)
"]" =
- #(make-music
    'SlurEvent
    'span-direction
    1)
- #(make-music
    'BeamEvent
    'span-direction
    1)

\score {
  \relative {
    \autoBeamOff
    r8 c' a' g16[ f] g8 c, f16[ e f] d
    e4( d\prall) c\fermata \bar "|." }
  \addlyrics {
    This on -- ly serves as an ex -- am -- ple. }
}

"[" =
- \tweak stencil ##f
- #(make-music
    'SlurEvent
    'span-direction
    -1)
- #(make-music
    'BeamEvent
    'span-direction
    -1)
"]" =
- #(make-music
    'SlurEvent
    'span-direction
    1)
- #(make-music
    'BeamEvent
    'span-direction
    1)

\score {
  \relative {
    \autoBeamOff
    r8 c' a' g16[ f] g8 c, f16[ e f] d
    e4( d\prall) c\fermata \bar "|." }
  \addlyrics {
    This on -- ly serves as an ex -- am -- ple. }
}


