\version "2.22.2"

\header {
  texidoc = "
The @code{arpeggioBracket} can be used to indicate the division of
voices where there are no stems to provide the information. This is
often seen in choral music.

"
  doctitle = "Using arpeggioBracket to make divisi more visible"
}
\include "english.ly"

\score {
  \relative c'' {
    \key a \major
    \time 2/2
    <<
      \new Voice = "upper"
      <<
        { \voiceOne \arpeggioBracket
          a2( b2
          <b d>1\arpeggio)
          <cs e>\arpeggio ~
          <cs e>4
        }
        \addlyrics { \lyricmode { A -- men. } }
      >>
      \new Voice = "lower"
      { \voiceTwo
        a1 ~
        a
        a ~
        a4 \bar "|."
      }      
    >>
  }
  \layout { ragged-right = ##t }
}



