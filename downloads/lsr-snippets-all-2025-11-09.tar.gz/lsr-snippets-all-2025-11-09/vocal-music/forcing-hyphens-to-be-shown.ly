\version "2.22.2"

\header {
  texidoc = "
If LilyPond does not think there is space for a hyphen, it will be
omitted.  The behaviour can be overridden with the
@code{minimum-distance} property of @code{LyricHyphen}.

"
  doctitle = "Forcing hyphens to be shown"
}
\relative c'' {
  c32 c c c 
  c32 c c c 
  c32 c c c 
  c32 c c c 
}
\addlyrics {
  syl -- lab word word
  \override LyricHyphen.minimum-distance = #1.0
  syl -- lab word word
  \override LyricHyphen.minimum-distance = #2.0
  syl -- lab word word
  \revert LyricHyphen.minimum-distance
  syl -- lab word word
}



