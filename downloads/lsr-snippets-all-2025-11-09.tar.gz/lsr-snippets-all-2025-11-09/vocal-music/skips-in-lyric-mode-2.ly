\version "2.22.2"

\header {
  texidoc = "
Although @code{s} skips cannot be used in @code{\\lyricmode} (it is
taken to be a literal @qq{s}, not a space), double quotes (@code{\"\"})
or underscores (@code{_}) are available.So for example: 

"
  doctitle = "Skips in lyric mode (2)"
}
<<
  \relative c'' { a4 b c d }
  \new Lyrics \lyricmode { a4 "" _ gap }
>>



