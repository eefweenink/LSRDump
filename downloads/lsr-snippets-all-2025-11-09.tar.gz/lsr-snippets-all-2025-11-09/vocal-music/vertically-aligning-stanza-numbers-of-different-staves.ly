\version "2.22.2"

\header {
  texidoc = "
It can happen that stanza numbers don't align vertically if the verses
are attached to different staves.  To fix that, override the
@code{self-alignment-X} property of the @code{LyricText} grob. 

"
  doctitle = "Vertically aligning stanza numbers of different staves"
}
\markup { default behavior }

<<
  \new Staff { b b b b }
  \lyrics {
    \set stanza = "3."
    a a a a
  }

  \new Staff { b b b b }
  \lyrics {
    \set stanza = "1."
    aaaaaaaaaa a a a
  }
  \lyrics {
    \set stanza = "2."
    a a a a
  }
>>

\markup \vspace #1
\markup {
  using \typewriter "self-alignment-X = #LEFT" }

<<
  \new Staff { b b b b }
  \new Lyrics \lyricmode {
    \set stanza = "3."
    a a a a
  }

  \new Staff { b b b b }
  \new Lyrics \lyricmode {
    \set stanza = "1."
    \once \override LyricText.self-alignment-X = #LEFT
    aaaaaaaaaa a a a
  }
  \new Lyrics \lyricmode {
    \set stanza = "2."
    a a a a
  }
>>

\paper { tagline = ##f }

