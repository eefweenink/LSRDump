\version "2.22.2"

\header {
  texidoc = "
With the @code{\\lyricsto} mechanism, individual lyric lines can be
associated with one melody line. For each lyric line, they can be tuned
whether to follow melismata or not. 

"
  doctitle = "lyric combine"
}
%% http://lsr.di.unimi.it/LSR/Item?id=223

<<
  \new Voice = "bla" \relative c'' {
    \autoBeamOff
    c2( d4) e8[ c b c] f4
  }
  \new Lyrics \lyricsto "bla"  { 
    bla ab blob blob 
  }
  \new Lyrics \lyricsto "bla"  {
    bla 

    \set ignoreMelismata = ##t
    
    blob

    %% note: effect of ignoreMelismata delayed one time step.
    \unset ignoreMelismata 
    blob
    
    blob
  }
  
  \new Lyrics \lyricsto "bla"  {
    nes ted lyrics voice with more words than no tes
  }
>>
  


