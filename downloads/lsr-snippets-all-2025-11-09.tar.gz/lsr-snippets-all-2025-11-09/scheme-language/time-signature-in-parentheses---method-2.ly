\version "2.22.2"

\header {
  texidoc = "
Another way to put the time signature in parentheses.

"
  doctitle = "Time signature in parentheses - method 2"
}
%% http://lsr.di.unimi.it/LSR/Item?id=733
%% see also http://lsr.di.unimi.it/LSR/Item?id=169
%% see also http://lsr.di.unimi.it/LSR/Item?id=734

#(define ((parenthesize-time up down) grob)
   (grob-interpret-markup grob
     (markup #:override '(baseline-skip . 0) #:number
       (#:line (
           #:vcenter "("
           (#:column (up down))
           #:vcenter ")" )))))

\relative c'' {
   \override Staff.TimeSignature.stencil = #(parenthesize-time "2" "4")      
   \time 2/4
   a4 b8 c
}

\paper { tagline = ##f }




