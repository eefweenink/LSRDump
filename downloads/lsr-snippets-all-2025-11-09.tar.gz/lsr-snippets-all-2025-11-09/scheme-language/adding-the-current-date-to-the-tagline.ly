\version "2.22.2"

\header {
  texidoc = "
There are a couple ways to get the current date in your score - using
Scheme and a header that suits you (as you may find in the @qq{Adding
the current date to a score} example), or placing the same Scheme code
in a @code{\\markup} block.


One more option is to place the date in the tagline. This places the
date at the bottom of the last page and appears like this -  


Engraved on April 26, 2009 with Lilypond 2.12.2 (http://lilypond.org)  

The format of the date can be changed according to these parameters:


* %a - is replaced by the locale's abbreviated weekday name. * %A - is
replaced by the locale's full weekday name. * %b - is replaced by the
locale's abbreviated month name. * %B - is replaced by the locale's
full month name. * %c - is replaced by the locale's appropriate date
and time representation. * %d - is replaced by the day of the month as
a decimal number [01,31]. * %I - is replaced by the hour (12-hour
clock) as a decimal number [01,12]. * %j - is replaced by the day of
the year as a decimal number [001,366]. * %m - is replaced by the month
as a decimal number [01,12]. * %M - is replaced by the minute as a
decimal number [00,59]. * %p - is replaced by the locale's equivalent
of either a.m. or p.m. * %U - is replaced by the week number of the
year (Sunday as the first day of the week) as a decimal number [00,53].
* %w - is replaced by the weekday as a decimal number [0,6], with 0
representing Sunday. * %W - is replaced by the week number of the year
(Monday as the first day of the week) as a decimal number [00,53]. All
days in a new year preceding the first Monday are considered to be in
week 0. * %x - is replaced by the locale's appropriate date
representation. * %X - is replaced by the locale's appropriate time
representation. * %y - is replaced by the year without century as a
decimal number [00,99]. * %Y - is replaced by the year with century as
a decimal number. * %Z - is replaced by the timezone name or
abbreviation, or by no bytes if no timezone information exists.
 

"
  doctitle = "Adding the current date to the tagline"
}
%% http://lsr.di.unimi.it/LSR/Item?id=563

\header {
  title = "Title"
  composer = "Composer"
  arranger = "Arranger"
  tagline = \markup {
    Engraved on
    #(strftime "%x at %X" (localtime (current-time)))
    with
    \with-url "http://lilypond.org/web/" {
      LilyPond #(lilypond-version) (http://lilypond.org/)
    }
  }
}

\relative c' {
  c4 d e f
}



