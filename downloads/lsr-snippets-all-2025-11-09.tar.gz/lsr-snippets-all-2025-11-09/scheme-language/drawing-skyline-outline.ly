\version "2.22.2"

\header {
  texidoc = "
<p>By setting the 'debug-skylines Scheme property, you can turn your
score into a nice funky artwork :-)</p>

<p>More seriously, drawing this skyline can be helpful to debug spacing
and collision issues. (Still, it does make your score pretty; so just
try it, no matter how much you really need to...)</p>

"
  doctitle = "Drawing skyline outline"
}
%% http://lsr.di.unimi.it/LSR/Item?id=256

%here starts the snippet:

#(ly:set-option 'debug-skylines)

{
  a,,1 | a'4 b' c'' d'' \break
  \repeat unfold 2 {a' b' c'' d''} | b''''1
}

\paper {
  ragged-right = ##t
  tagline = ##f
}

