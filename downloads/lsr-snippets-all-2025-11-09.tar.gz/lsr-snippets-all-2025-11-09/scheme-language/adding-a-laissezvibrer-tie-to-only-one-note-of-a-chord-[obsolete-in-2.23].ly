\version "2.22.2"

\header {
  texidoc = "
Sometimes it is required to apply a laissezVibrer tie to a specific
note in a chord, for instance in a piano fingering where one finger of
a chord should temporarily act as a pivot while the other fingers are
moving to the the next chord. Here is a way to achieve it. 

"
  doctitle = "Adding a laissezVibrer tie to only one note of a chord [obsolete in 2.23]"
}
% http://lsr.di.unimi.it/LSR/Item?id=714

%LSR after a mail from Robin Bannister http://lists.gnu.org/archive/html/lilypond-user/2009-04/msg00344.html

% laissezVibrer using feta char overlay: dir: UP or DOWN (or pad per magnitude)
#(define (flvSt dir)
  (lambda (grob)
   (define dirsign
    (if (positive? dir) + -) )
   (let* ((pos (ly:grob-property grob 'staff-position))
          (height (if (odd? pos) +0.8 +0.55)) (angle +90))
    (ly:stencil-combine-at-edge (ly:note-head::print grob) 0 1
     (grob-interpret-markup grob (markup
                                  #:with-dimensions '(0 . 0) '(0 . 0)
                                  #:concat (#:hspace (abs dir)
                                            #:raise (dirsign height)
                                            #:rotate (dirsign angle)
                                            #:musicglyph "accidentals.rightparen" ))) 0))))

flvUP =
\once \override NoteHead.stencil = #(flvSt UP)

flvDOWN =
\once \override NoteHead.stencil = #(flvSt DOWN) % or \tweak stencil   ___ditto____

%% Remark:
%% change next two definitions to the commented ones during LSR 2.20-upgrade
flvUPtw =
#(define-music-function (mus) (ly:music?)
  #{ \tweak stencil  #(flvSt UP) $mus #})

flvDOWNtw =
#(define-music-function (mus) (ly:music?)
  #{ \tweak stencil  #(flvSt DOWN) $mus #})
  
%% flvUPtw = \tweak stencil  #(flvSt UP) \etc
%% flvDOWNtw = \tweak stencil  #(flvSt DOWN) \etc

\relative c' {
  <a e'>4\laissezVibrer s
  <\flvDOWNtw a \flvUPtw e'>4 s
  <a \flvUPtw e'>4 s
  <\flvDOWNtw a e'>4 s
}



