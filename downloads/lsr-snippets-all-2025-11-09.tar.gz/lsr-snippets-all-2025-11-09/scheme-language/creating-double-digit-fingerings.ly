\version "2.22.2"

\header {
  texidoc = "
Creating fingerings larger than 5 is possible.

"
  doctitle = "Creating double-digit fingerings"
}
\relative c' {
  c1-10
  c1-50
  c1-36
  c1-29
}


