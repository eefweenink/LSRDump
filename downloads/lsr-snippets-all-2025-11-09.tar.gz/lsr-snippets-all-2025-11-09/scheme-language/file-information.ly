\version "2.22.2"

\header {
  texidoc = "
Display ly file information in markup, including file name, file size,
 LilyPond version, date processed, time processed, time last modified,
and
 the LilyPond command line.

"
  doctitle = "File Information"
}
#(define comml    (command-line))
#(define filen    input-file-name)
#(define siz      (object->string (stat:size (stat filen))))
#(define ver      (lilypond-version))
#(define dat      (strftime "%m/%d/%Y" (localtime (current-time))))
#(define tim      (strftime "%H:%M:%S" (localtime (current-time))))
#(define modt     (stat:mtime (stat filen)))
#(define modts    (strftime "%m/%d/%Y %H:%M:%S" (localtime modt)))

\markup \column {
  \line { "File Name = "        \filen }
  \line { "File Size = "        \siz   }
  \line { "LilyPond Version = " \ver   }
  \line { "Date Processed = "   \dat   }
  \line { "Time Processed = "   \tim   }
  \line { "Last Modified = "    \modts }
  \line { "Command Line = "     \comml }
}


