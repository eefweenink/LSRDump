\version "2.22.2"

\header {
  texidoc = "
If you do not want to use lilypond's automatic barlines but rather just
insert barlines with \\bar, the bar counter will not be increased, and
therefore two problems may occur:

* accidentals will not be properly reset, * and the printed barnumber
will be wrong.

This snippet defines a function, \\increaseBarNumber that - yeah -
increases the barnumber, thereby making accidentals and typeset
barnumbers behave correctly. Just call it whenever you insert a manual
bar.Also defines short hand functions @code{\\ibar} and @code{\\nibar}
- as illustrated by the example. 

"
  doctitle = "Free Meter - increasing the barnumber wherever you want"
}
%% http://lsr.di.unimi.it/LSR/Item?id=333

%% Updaters remark:
%% This snippet actually doubles the one in 2.24.-NR. "Unmetered music"
%% Thus it will be deleted soon.
%% For now replacing it with code from said NR-section.
%% Ofcourse, the description is now wrong/misleading --Harm

cadenzaMeasure = {
  \cadenzaOff
  \partial 1024 s1024
  \cadenzaOn
}

\score {
  \new Staff \with { \remove Time_signature_engraver } {
    \cadenzaOn
    \accidentalStyle modern-cautionary
    \key a \major
    \repeat unfold 2 {
      c'8 dis' eis'  eis'
      \cadenzaMeasure
      c'4 dis'  e' eis' \cadenzaMeasure \bar ";"
      c' dis' eis'8 dis' eis' \cadenzaMeasure
      c'1 dis' eis' eis'2 \cadenzaMeasure \bar "||"
    }
    \cadenzaOff
    b1
    \bar "|."
  }

  \layout {
    \context {
      \Score
      \override BarNumber.break-visibility = ##(#f #t #t)
    }
  }
}

