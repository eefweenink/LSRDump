\version "2.22.2"

\header {
  texidoc = "
Traditionally, vocal scores used beams to indicate melisma, while
modern vocal scores tend to use slurs.  With this snippet's
@code{\\beamsToSlurs} music function you can easily produce either type
of output from the same music input, allowing you to have both
traditional and modern vocal engraving with one unique source.  The
function automatically converts manually typeset beams: @code{[ ]}
...into slurs: @code{( )}.

"
  doctitle = "Automatically convert beams [ ] into slurs ( ) to indicate melisma"
}
% a music function to convert manually typeset beams: [ ] ...into slurs: ( )

beamsToSlurs =
#(define-music-function (music) (ly:music?)
   (music-map
     (lambda (m)
       (if (not (null? (ly:music-property m 'articulations)))
           (for-each
             (lambda (a)
               (if (music-is-of-type? a 'beam-event)
                   (begin
                    (ly:music-set-property! a 'name 'SlurEvent)
                    (ly:music-set-property! a 'types
                      (append
                       (delete 'beam-event (ly:music-property a 'types))
                       '(slur-event)))
                    (ly:music-set-property! a 'spanner-id ""))))
             (ly:music-property m 'articulations))
             m)
       m)
     music))

%%%%%%%%%%%%%%%%%%%%%%%%%

music = {
  \time 2/4
  | c'8[ d'] e' f'
  | g'[ a'] b' c''
}

words = \lyricmode {
  la li lo 
  la li lo
}

<<
  \new Staff \with { instrumentName = "Traditional" } 
    { \autoBeamOff \music }
    \addlyrics \words
  
  \new Staff \with { instrumentName = "Modern" }
    \beamsToSlurs \music
    \addlyrics \words
>>


