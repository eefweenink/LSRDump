\version "2.22.2"

\header {
  texidoc = "
You are probably familiar with the default Lilypond tagline @qq{Music
engraving by LilyPond 2.1x.xx—www.lilypond.org}, that is automatically
added to your scores.

Not only can you fully remove it, by setting the tagline variable to
@code{f} (just add @code{tagline = ##f} in your header block), but you
are also welcome to translate it (and the LilyPond authors invite you
to do so if you want to promote this great software) or customize it
the way you like it!


In this snippet, we have taken the original tagline definition in the
titling-init.ly file, and therefore we can tweak it the way we want.
The right version number will automatically be added. 

"
  doctitle = "Translating the default LilyPond tagline"
}
%% http://lsr.di.unimi.it/LSR/Item?id=366

%LSR thanks to John Mandereau for this snippet

\header {
  %% taken from titling-init.ly
  tagline = \markup {
    \with-url
    "http://lilypond.org/web/"
    \line {
      %% feel free to translate this line to your own language
      "This score has been wonderfully engraved thanks to the awesome LilyPond"
      $(lilypond-version)
      \char ##x2014
      "http://lilypond.org"
    }
  }
}

\relative c' {
  c4 d e f
}



