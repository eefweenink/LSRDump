\version "2.22.2"

\header {
  texidoc = "
To color all objects on a staff is a laborious task. However, this can
be automated by using some Scheme code to access the list of objects
contained in @code{all-grob-descriptions}. All graphical objects which
live in the @code{Staff} context can then be colored by setting their
@code{color} property.


This snippet is obsolete in LilyPond 2.25, which introduces a much
simpler method:


\\layout @{ property-defaults.color = \"blue\" @}

"
  doctitle = "Setting a color for all staff objects automatically [obsolete in 2.25]"
}
%% http://lsr.di.unimi.it/LSR/Item?id=443

#(define (override-color-for-all-grobs color)
  (lambda (context)
   (let loop ((x all-grob-descriptions))
    (if (not (null? x))
     (let ((grob-name (caar x)))
      (ly:context-pushpop-property context grob-name 'color color)
      (loop (cdr x)))))))

\relative c' {
  \applyContext #(override-color-for-all-grobs (x11-color 'blue))
  c4\pp\< d e f
  \grace { g16[( a g fis]) } g1\ff\!
}



