\version "2.22.2"

\header {
  texidoc = "
Typing music for many consecutive tremolos with the same base duration
becomes tedious. This is a function to make this easier. By default
LilyPond does not unfold tremolo repeats for midi. A function for
unfolding only tremolo repeats is also included. 

"
  doctitle = "Consecutive tremolos"
}
music = \relative c' {
  c4:16 d2: e4:
  f1:  
  g8: f: e: d: d2:
}

musicMidi = \relative c' {
  \repeat tremolo 4 c16 
  \repeat tremolo 8 d
  \repeat tremolo 4 e
  \repeat tremolo 16 f
  \repeat tremolo 2 { g f e d }
  \repeat tremolo 8 d
}

\score {
  \new Staff { 
    \music 
    %\musicMidi
  }
}

\score {
  \new Staff \relative c' {
    \unfoldRepeats
%% Tremolos entered with `:[number]` are not are reflected in the MIDI output:
  % \music 
   \musicMidi
  }
  \midi { }
}



