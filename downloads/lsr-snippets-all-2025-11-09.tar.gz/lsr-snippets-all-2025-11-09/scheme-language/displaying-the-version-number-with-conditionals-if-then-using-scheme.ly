\version "2.22.2"

\header {
  texidoc = "
Thanks to its implementation of GUILE, LilyPond makes high level
functionalities relatively easy to accomplish.

<p>In this example, the title will mention the current version (i.e.
the version the snippet was compiled with, regardless which version was
originally used).

"
  doctitle = "Displaying the version number with conditionals (if then) using Scheme"
}
%% http://lsr.di.unimi.it/LSR/Item?id=264

\paper { tagline = ##f }

#(define pieceTagLine
  (if (not (defined? 'pieceTagLine))
      (string-append "You are running version " (lilypond-version))
      pieceTagLine))

\header{
  title = \pieceTagLine
}

{ c'4 }



