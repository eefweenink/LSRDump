\version "2.22.2"

\header {
  texidoc = "
This scheme function extracts a string from markup, removing any
formatting information. 

"
  doctitle = "Extracting text from markup"
}
%% http://lsr.di.unimi.it/LSR/Item?id=747

#(define-markup-command (plain-text layout props arg)(markup?)
                        (interpret-markup layout props (markup (markup->string arg))))

ttt = \markup {
  \normal-text { good day and \concat { hello \bold { world } } \italic { and moon }  }
}

\header {
  title = \ttt
  subtitle = \markup { \normal-text { \italic { \plain-text \ttt } } }
}
\relative c' {
  c
}



