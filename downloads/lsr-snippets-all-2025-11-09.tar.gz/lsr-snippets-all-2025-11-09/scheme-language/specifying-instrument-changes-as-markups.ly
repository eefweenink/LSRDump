\version "2.22.2"

\header {
  texidoc = "
This is just a small useful macro when you need to specify multiple
instrument changes on a same staff.

Just write @code{\\inst \"Name} before the note the markup should be
attached to.

"
  doctitle = "Specifying instrument changes as markups"
}
%% http://lsr.di.unimi.it/LSR/Item?id=349

%LSR modified by P.P.Schneider on Feb.2014

inst =
#(define-music-function (string) (string?)
  #{ <>^\markup \bold \box #string #})

\relative c' { c \inst "Horn" d e f } 



