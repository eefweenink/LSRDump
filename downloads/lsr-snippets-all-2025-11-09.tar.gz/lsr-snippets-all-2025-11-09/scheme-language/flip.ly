\version "2.22.2"

\header {
  texidoc = "
@code{\\scale #'(-1 . 1)} workaround.

"
  doctitle = "Flip"
}
%% http://lsr.di.unimi.it/LSR/Item?id=905

% by P.P.Schneider on March 2014.

\paper { tagline = ##f }

%here starts the snippet:

%%%% \flip:
#(define-markup-command (flip layout props arg) (markup?) 
   (interpret-markup layout props
     (markup 
      #:concat (
        #:null 
        #:scale (cons -1 1)
          #:line (arg)))))
%%%% end \flip.

myScr= { c'1 }

\markuplist {
  \italic\concat { 
    "This markup uses " 
    \typewriter "\scale #'(-1 . 1)" 
    " to flip a score"
    \hspace #0.3 ":" 
  }
  \vspace #0.2
  \line { 
    \concat { 
      "This flipped score" 
      \hspace#.3 
      ":" 
    } 
    \raise #1
    \scale #'(-1 . 1)
    \score {
      \myScr
      \layout {
        indent = 0
      }
    }
    " is mine."
  }
  \vspace#1
  \concat\italic { 
    "Here's the side-effect when starting a markup with " 
    \typewriter "\scale #'(-1 . 1)"
    \hspace #0.3 
    ":"
  }
  \vspace#.2
  \line { 
    \scale #'(-1 . 1)
    \score {
      \myScr
      \layout {
        indent = 0
      }
    }
    \lower #1
    \concat { 
      " My beloved score is leaving"
      \hspace #0.3 
      "!"
    }
  }
  \vspace#1
  \concat\italic { 
    "Here's a possible workaround using " 
    \typewriter "\left-align"
    \hspace #0.3 
    ":"
  }
  \vspace#.2
  \left-align
  \line { 
    \scale #'(-1 . 1) 
    \score {
      \myScr
      \layout {
        indent = 0
      }
    }
    \lower #1
    \concat { 
      " It's coming back"
      \hspace #0.3 
      "!"
    }
  }
  \vspace#1
  \concat\italic {
    "And this one uses a simple " 
    \typewriter "\flip"
    " command that avoids using " 
    \typewriter "\left-align"
    \hspace #0.3 
    ":"
  }
  \vspace#.2
  \line {
    \flip
    \score {
      \myScr
      \layout {
        indent = 0
      }
    }
    \lower #1
    \concat { 
      " Now it's home."
    }
  }
}



