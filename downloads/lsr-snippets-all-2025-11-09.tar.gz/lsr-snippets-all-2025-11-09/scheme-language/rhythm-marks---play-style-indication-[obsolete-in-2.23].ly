\version "2.22.2"

\header {
  texidoc = "
<p>If a piece is written in e.g. even eight notes, but you want to
indicate that the rhythm of the even eighths should be played e.g. with
a swing rhythm, you can use this. This can be used and tweaked for
various rhythm styles/changes.</p>

<p>This snippet is obsolete with LilyPond 2.23.x: use the new built-in
<code>\\rhythm</code> markup command, e.g.,</p>

<p><pre> \\tempo \\markup @{ Swing \\rhythm @{ 8[ 8] @} = \\rhythm @{
\\tuplet 3/2 @{ 8( 8) 8 @} @} @} </pre></p>

"
  doctitle = "Rhythm marks / play style indication [obsolete in 2.23]"
}
%% http://lsr.di.unimi.it/LSR/Item?id=204

%% This rewrite uses the \rhythm markup-command from 2.24.
%% We choose to use `TextMark' to display the rhythm marks, because 
%% `MetronomeMark' uses hardcoded bold-markup in `metronome-markup' and we want
%% to have the possibility to apply general overrides for 'font-series.
%% If that is not desired you may replace `TextMark' with `MetronomeMark' and
%% \textMark with \tempo.
%%
%% Some adjustments are applied, see inline comments, in order to get
%% most pleasing output.
%% Probably theses adjustments must be modified if MetronomeMark is used
%% instead of TextMark (not tested).
%%
%% For unknown reasons the layout-settings for StandaloneRhythmScore/Staff/Voice
%% need to be at toplevel.
%%
%% --Harm


\layout {
  ragged-right= ##t
  indent = 0 
  \context {
    \Score
    \override TextMark.font-shape = #'italic
    %% get a bit more space between rows of a columned TextMark
    \override TextMark.baseline-skip = 2.5
  }
  \context {
    \StandaloneRhythmScore
    %% get a more tight spacing, default is (ly:make-moment 1/10)
    \override SpacingSpanner.common-shortest-duration =
      #(ly:make-moment 1/7)
  }
  \context {
    \StandaloneRhythmStaff
    %% Make it all smaller
    fontSize = #-4
    %% 2.24.0 has a glitch with Dots.
    %% This override to cure it should be deleted with 2.25.0
    \override DotColumn.positioning-done = 
      #(lambda (grob)
        (let* ((dots-array (ly:grob-object grob 'dots #f))
               (dots
                 (if dots-array
                     (ly:grob-array->list dots-array)
                     '())))
          (for-each
            (lambda (dot)
              ;; The value 1.1 was found by try and error
              ;; NB Works only for one Dot
              (ly:grob-translate-axis! dot 1.1 X))
            dots)
          #t))
  }
  \context {
    \StandaloneRhythmVoice
    %% Adjust Beam and Stem.details to have the beamed and (flagged) stems
    %% ending at same height. See IR for the defaults.
    %% NB proofed only for 1/8 and 1/16 
    \override Stem.details.beamed-lengths = #'(3.0 2.5)
    \override Stem.details.lengths = #'(2.3)
    \override Stem.details.beamed-minimum-free-lengths = #'(0.5)
    \override Stem.details.beamed-extreme-minimum-free-lengths = #'(0.5)
    \override Beam.beam-thickness = 0.3
    \override Beam.length-fraction = 0.65
  }
}

%% conveniance definitions

semibreve = \markup \rhythm { { 1 } }
minim = \markup \rhythm { { 2 } }
crotchet = \markup \rhythm { { 4 } }
quaver = \markup \rhythm { { 8 } }
doubleQuaver = \markup \rhythm { 8[ 8] }

dottedRhythm = \markup \rhythm { 8.[ 16] }

tupletI = \markup \rhythm { \tuplet 3/2 { 8( 8) 8 } }
tupletII = \markup \rhythm { \tuplet 3/2 { 4 8 } }

%% score

{
  \textMark \markup { Swing \doubleQuaver = \tupletI }
  g'1 1 1
  \textMark \markup { straight \quaver = \quaver }
  g'1 1 1
  \textMark \markup { Shuffle \doubleQuaver = \dottedRhythm }
  g'1 1 1
  
  \break
  
  \textMark \markup { straight \doubleQuaver = \doubleQuaver }
  g'1 1 1
  \textMark \markup { Swing \doubleQuaver = \tupletII }
  g'1 1 1
  \textMark \markup { in 2 \minim = \crotchet }
  g'1 1 1
  
  \break
  
  \textMark \markup { Swing feel \dottedRhythm = \tupletII }
  g'1 1 1
  \textMark \markup { Maestoso \minim = \semibreve }
  g'1 1 1
  \textMark \markup { suassa \minim = \semibreve }
  g'1 1 1
  
  \break
  
  \textMark \markup \column { \line { \doubleQuaver = \tupletI } Swing }
  g'1 1 
  \textMark \markup \column { \line { \quaver = \quaver } straight }
  g'1 1
  \textMark \markup \column { \line { \doubleQuaver = \dottedRhythm } Shuffle }
  g'1 1
  \textMark \markup \column { \line { \doubleQuaver = \doubleQuaver } straight }
  g'1 1
  \textMark \markup \column { \line { \doubleQuaver = \tupletII } Swing }
  g'1 1
  \textMark \markup \column { \line { \minim = \crotchet } "in 2" }
  g'1 1
  
  \break
  
  \textMark \markup \column { \line { \dottedRhythm = \tupletII } "Swing feel" }
  g'1 1
  \textMark \markup \column { \line { \minim = \semibreve } Maestoso }
  g'1 1 1
  \bar "|."
}


%% Old code commented for now
%{
%%% Function: rhythmMark
%%% ============================================================
%%%  Purpose: print a sophisticated rehearsal mark e.g
%%%           for rhythm directives
%%%    Usage: \rhythmMark label music1 music2
%%% ------------------------------------------------------------
%%% Variable: label (string)
%%% ------------------------------------------------------------
%%% Variable: music1 (ly:music)
%%% ------------------------------------------------------------
%%% Variable: music2 (ly:music)
%%% ------------------------------------------------------------
%%%  Example: \rhythmMark #"Swing" \rhyMarkIIEighths
%%%                 \rhyMarkSlurredTriplets
%%% ------------------------------------------------------------
%%% Constants:
%%%           rhythmMarkStaffReduce = #-3
%%%           rhythmMarkLabelFontSize = #-2
%%% ------------------------------------------------------------
%%%  Comment: see below for predefined values for music1&2
%%% ============================================================

rhythmMarkStaffReduce = #-3
rhythmMarkLabelFontSize = #-2

rhythmMark = #(define-music-function (label musicI musicII ) (string? ly:music? ly:music?)
   #{
      \mark \markup {
        \line \general-align #Y #DOWN {
          \combine
            \italic \fontsize #rhythmMarkLabelFontSize $label
            \transparent \italic \fontsize #rhythmMarkLabelFontSize f

          \score {                     % 2nd column in line
            \new Staff \with {
              fontSize = #rhythmMarkStaffReduce
              \override StaffSymbol.staff-space = #(magstep rhythmMarkStaffReduce)
              \override StaffSymbol.line-count = #0
              \override VerticalAxisGroup.Y-extent = #'(-0.85 . 4)
            }

            {
              \relative c' { \stemUp $musicI }
             
%             \override Score.SpacingSpanner.strict-note-spacing = ##t
              \once \override Score.TextScript.Y-offset = #-0.4
              s4.^\markup{ \halign #-1 \italic "=" }
              
              \relative c' { \stemUp $musicII }
            } 
            
            \layout {
              ragged-right= ##t
              indent = 0
              \context {
                \Staff
                \remove "Clef_engraver"
                \remove "Time_signature_engraver"
              }
            } % layout end

          } % Score end

        } % line end
      } % markup end
   #})

%%% Function: rhythmMarkC
%%% ============================================================
%%%  Purpose: print a sophisticated rehearsal mark e.g for
%%%           rhythm directives in a column (music on top)
%%%    Usage: \rhythmMarkC label music1 music2
%%% ------------------------------------------------------------
%%% Variable: label (string)
%%% ------------------------------------------------------------
%%% Variable: music1 (ly:music)
%%% ------------------------------------------------------------
%%% Variable: music2 (ly:music)
%%% ------------------------------------------------------------
%%%  Example: \rhythmMarkC #"Swing" \rhyMarkIIEighths
%%%                 \rhyMarkSlurredTriplets
%%% ------------------------------------------------------------
%%% Constants:
%%%           rhythmMarkCStaffReduce = #-4
%%%           rhythmMarkCLabelFontSize = #-2
%%% ------------------------------------------------------------
%%%  Comment: see below for predefined values for music1&2
%%% ============================================================

rhythmMarkCStaffReduce = #-4
rhythmMarkCLabelFontSize = #-2

rhythmMarkC = #(define-music-function (label musicI musicII ) (string? ly:music? ly:music?)
   #{
      \mark \markup
      {
        \combine

          \line {
            \hspace #0
            \translate #'(-0.1 . -3.25) \italic \fontsize #rhythmMarkCLabelFontSize $label
          } % end Line

          \line \vcenter {

              \score {                 % 1st column in line

                \new Staff \with {
                  fontSize = #rhythmMarkCStaffReduce
                  \override StaffSymbol.staff-space = #(magstep rhythmMarkCStaffReduce)
                  \override StaffSymbol.line-count = #0 
                  \override VerticalAxisGroup.Y-extent = #'(0 . 0)  % td
                }

                \relative c' { \stemUp $musicI }

                \layout {
                  ragged-right= ##t
                  indent = 0
                  \context {
                    \Staff
                    \remove "Clef_engraver"
                    \remove "Time_signature_engraver" }
                } % layout

              } % 1st score

              \hspace #-0.1            % 2nd column in line

                                       % 3rd column in line
              \italic \fontsize #rhythmMarkCStaffReduce "="

              \score {                 % 4th column in line

                \new Staff \with {
                  fontSize = #rhythmMarkCStaffReduce
                  \override StaffSymbol.staff-space = #(magstep rhythmMarkCStaffReduce)
                  \override StaffSymbol.line-count = #0 
                  \override VerticalAxisGroup.Y-extent = #'(0 . 0)  % td
                }

                \relative c' {
                  \stemUp $musicII
                }

                \layout {
                  ragged-right= ##t
                  indent = 0
                  \context {
                    \Staff
                    \remove "Clef_engraver"
                    \remove "Time_signature_engraver" }
                } % layout

              } % 2nd score end

            } % line end
          % end combine
        } % markup end
   #})

%%% predefined ly:music-Variables for use
%%% in function rhythmMark and rhythmMarkC
%%% ============================================================
rhyMarkI = { b'1*1/8 }

rhyMarkII = { b'2*1/4 }

rhyMarkIV = { b'4*1/2 }

rhyMarkEighth = { b'8 }

rhyMarkIIEighths = {
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/4) % tight
  \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 3/16) % even
  b'8[ b8]
}
rhyMarkTriplets = {
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/2) % super-tight
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/4) % tight
  \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 3/16) % even
  \tuplet 3/2 { b'4 b8 }
}
rhyMarkSlurredTriplets = {
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/4) % tight
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 5/32) % slighty tighter as even
  \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/8) % even
  \tuplet 3/2 { b'8 ~ b8 b8 }
}
rhyMarkDottedEighths = {
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/4) % tight
  \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 3/16) % even
  % \override Score.SpacingSpanner.common-shortest-duration = #(ly:make-moment 1/8) % loose
  { b'8.[ b16*2] }
}


%%% Begin Example
%%% ============================================================

spacer = {
  | g'1
  \noBreak
  | g'1
  | g'1
}

spacerII = {
  | g'1
  \noBreak
  | g'1
}

\score {
  {
    \override Score.RehearsalMark.self-alignment-X = #LEFT
    \override Score.BarNumber.break-visibility = #all-invisible
%    \override Score.RehearsalMark.padding = #-2
    \once \override Score.RehearsalMark.X-offset = #5  % td
    \rhythmMark #"Swing" \rhyMarkIIEighths \rhyMarkSlurredTriplets
    \spacer
    \rhythmMark #"straight" \rhyMarkEighth \rhyMarkEighth
    \spacer
    \rhythmMark #"Shuffle" \rhyMarkIIEighths \rhyMarkDottedEighths
    \spacer
    \once \override Score.RehearsalMark.X-offset = #5  % td
    \rhythmMark #"straight" \rhyMarkIIEighths \rhyMarkIIEighths
    \spacer
    \rhythmMark #"Swing" \rhyMarkIIEighths \rhyMarkTriplets
    \spacer
    \rhythmMark #"in 2" \rhyMarkII \rhyMarkIV
    \spacer
    \once \override Score.RehearsalMark.X-offset = #5  % td
    \rhythmMark #"Swing feel" \rhyMarkDottedEighths \rhyMarkTriplets
    \spacer
    \rhythmMark #"Maestoso" \rhyMarkII \rhyMarkI
    \spacer
    \rhythmMark #"suassa" \rhyMarkII \rhyMarkI % This is just to proof that the basline-fake really works
    \spacer
    \once \override Score.RehearsalMark.X-offset = #5  % td
    \break
    \rhythmMarkC #"Swing" \rhyMarkIIEighths \rhyMarkSlurredTriplets
    \spacerII
    \rhythmMarkC #"straight" \rhyMarkEighth \rhyMarkEighth
    \spacerII
    \rhythmMarkC #"Shuffle" \rhyMarkIIEighths \rhyMarkDottedEighths
    \spacerII
    \rhythmMarkC #"straight" \rhyMarkIIEighths \rhyMarkIIEighths
    \spacerII
    \rhythmMarkC #"Swing" \rhyMarkIIEighths \rhyMarkTriplets
    \spacerII
    \rhythmMarkC #"in 2" \rhyMarkII \rhyMarkIV
    \spacerII
    \once \override Score.RehearsalMark.X-offset = #5  % td
    \rhythmMarkC #"Swing feel" \rhyMarkDottedEighths \rhyMarkTriplets
    \spacerII
    \rhythmMarkC #"Maestoso" \rhyMarkII \rhyMarkI
    \spacerII
  }
  
  \layout {
    ragged-right= ##t
    indent = 0       
  }
}

\paper {
  system-system-spacing.padding = #4
}
%}

\paper { tagline = ##f }
