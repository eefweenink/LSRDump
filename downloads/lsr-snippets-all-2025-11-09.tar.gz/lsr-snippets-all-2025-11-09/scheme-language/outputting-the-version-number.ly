\version "2.22.2"

\header {
  texidoc = "
It is possible to print the version number of LilyPond in markup. 

"
  doctitle = "Outputting the version number"
}
\markup { Processed with LilyPond version #(lilypond-version) }


