\version "2.22.2"

\header {
  texidoc = "
This snippet demonstrates how to obtain automatic ordered rehearsal
marks, but from the letter or number desired.

"
  doctitle = "Forcing rehearsal marks to start from a given letter or number"
}
\relative c'' {
  c1 \mark \default
  c1 \mark \default
  c1 \mark \default
  c1 \mark #14
  c1 \mark \default
  c1 \mark \default
  c1 \mark \default
  c1
}



