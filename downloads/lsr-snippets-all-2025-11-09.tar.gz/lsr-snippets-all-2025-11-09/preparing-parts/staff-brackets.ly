\version "2.22.2"

\header {
  texidoc = "
Staffs can be nested in various combinations. Here, @code{StaffGroup}
and @code{ChoirStaff} produce similar straight brackets, whereas 
@code{GrandStaff} produces curly brackets. In @code{InnerStaffGroup} 
and @code{InnerChoirStaff}, the brackets are shifted leftwards.




"
  doctitle = "Staff brackets"
}
%% http://lsr.di.unimi.it/LSR/Item?id=137

myMusic = { c' d' e' f' }

\score { 
  <<
    \new StaffGroup << 
      \new Staff \myMusic
      \new StaffGroup <<
        \new Staff \myMusic
        \new GrandStaff <<
          \new Staff \myMusic
          \new Staff \myMusic
        >>
        \new Staff \myMusic
      >>
      \new ChoirStaff <<
        \new Staff \myMusic
        \new StaffGroup <<
          \new Staff \myMusic
        >>
        \new Staff \myMusic
      >>
    >>
    \new ChoirStaff << 
      \new Staff \myMusic
      \new ChoirStaff <<
        \new Staff \myMusic
        \new Staff \myMusic
      >>
      \new Staff \myMusic
    >>
  >>
  \layout { 
    raggedright = ##t 
  }
}



