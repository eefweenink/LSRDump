\version "2.22.2"

\header {
  texidoc = "
Making a cue containing lyrics. This is just a combination of solutions
from the Notation Reference.

"
  doctitle = "Cue with lyrics"
}
%% http://lsr.di.unimi.it/LSR/Item?id=347

%% modified by Harm on Feb 15, 2014
%% http://lilypond.1069038.n5.nabble.com/LSR-v2-18-quot-Cue-with-lyrics-quot-cannot-update-tc159296.html#none

smallerFontsize = { \set fontSize = #-2 }

\addQuote twinkle \new Voice = "cue" \relative c' { c4 c g' g }

\score {
  \new Staff = "cuelyricdemo"
    <<
    \new Voice
      \relative c'' {
        \cueDuring #"twinkle" #1 { R1 }
        a4 a g2
      }
    \new Lyrics = "cueLyrics"
      \lyricsto "cue" {
        \smallerFontsize
        Twink -- le, twink -- le
      }
    >>
}



