\version "2.22.2"

\header {
  texidoc = "
In LilyPond 2.24.0 the @code{\\textMark} command and the normal 
@code{\\mark} command happily coexist.

Furthermore the sophisticated @code{\\repeat segno} command is
available, see here.

Thus this lsr snippet is heavily shortened compared with previous
versions.



"
  doctitle = "Segno / Coda on top of rehearsal mark"
}
%% http://lsr.di.unimi.it/LSR/Item?id=202


%% some variables
%% -----------------

markDefault = \mark \default

markDefaultSegno = {
  \textMark \markup \musicglyph "scripts.segno"
  \mark \default
}

markDefaultCoda = {
  \textMark \markup \musicglyph "scripts.coda"
  \mark \default
}

\score {
  \relative c' {
    c4 d e f
    \markDefault
    g a b c
    \markDefaultSegno
    c b a g
    \markDefault
    f e d c
    \markDefaultCoda
    c d e f
    \markDefault
    \bar "|."
  }
  \layout {
    indent = 0\cm
    \context {
      \Score
      rehearsalMarkFormatter = #format-mark-box-letters
      \override TextMark.self-alignment-X = #CENTER
      \override TextMark.outside-staff-priority = 1600
    }
  }
}

