\version "2.22.2"

\header {
  texidoc = "
Two different bells, entered with 'cb' (cowbell) and 'rb' (ridebell).

"
  doctitle = "Cow and ride bell example"
}
\paper { tagline = ##f }

#(define mydrums '((ridebell default #f  3)
                   (cowbell  default #f -2)))

\new DrumStaff \with { instrumentName = #"Different Bells" }

\drummode {
  \set DrumStaff.drumStyleTable = #(alist->hash-table mydrums)
  \set DrumStaff.clefPosition = 0.5
  \override DrumStaff.StaffSymbol.line-positions = #'(-2 3)
  \override Staff.BarLine.bar-extent = #'(-1.0 . 1.5)

  \time 2/4
  rb8 8 cb8 16 rb16-> ~ |
  16 8 16 cb8 8 |
}

