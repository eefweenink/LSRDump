\version "2.22.2"

\header {
  texidoc = "
For improvisations or taqasim which are temporarily free, the time
signature can be omitted and @code{\\cadenzaOn} can be used.  Adjusting
the accidental style might be required, since the absence of bar lines
will cause the accidental to be marked only once.  Here is an example
of what could be the start of a hijaz improvisation:

"
  doctitle = "Arabic improvisation"
}
\include "arabic.ly"

\relative sol' {
  \key re \kurd
  \accidentalStyle forget
  \cadenzaOn
  sol4 sol sol sol fad mib sol1 fad8 mib re4. r8 mib1 fad sol
}



