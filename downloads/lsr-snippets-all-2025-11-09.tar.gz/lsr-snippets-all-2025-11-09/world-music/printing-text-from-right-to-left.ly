\version "2.22.2"

\header {
  texidoc = "
It is possible to print text from right to left in a markup object, as
demonstrated here.

"
  doctitle = "Printing text from right to left"
}
{
  b1^\markup {
    \line { i n g i r u m i m u s n o c t e }
  }
  f'_\markup {
    \override #'(text-direction . -1)
    \line { i n g i r u m i m u s n o c t e }
  }
}



