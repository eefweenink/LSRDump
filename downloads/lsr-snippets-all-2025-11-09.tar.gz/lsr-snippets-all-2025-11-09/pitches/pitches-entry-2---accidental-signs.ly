\version "2.22.2"

\header {
  texidoc = "
A sharp is formed by adding -is to the end of a pitch name and a flat
is formed by adding -es. Double sharps and double flats are obtained by
adding -isis or -eses. These names are the Dutch note names. In Dutch,
aes is contracted to as, but both forms are accepted. Similarly, both
es and ees are accepted.

"
  doctitle = "Pitches entry 2 - accidental signs"
}
%% http://lsr.di.unimi.it/LSR/Item?id=153

\relative c'' {
  ceses4
  ces
  c
  cis
  cisis
}



