\version "2.22.2"

\header {
  texidoc = "
This snippet places a small parenthesized stemless note head above
harmonics to indicate the sounding pitch.

"
  doctitle = "Harmonics with parenthesized stemless note head"
}
%% http://lsr.di.unimi.it/LSR/Item?id=544

\relative c'' {
  \override Staff.NoteColumn.ignore-collision = ##t
  \override NoteHead.style = #'harmonic-mixed
  <<
    {
      \oneVoice
      <a e'\harmonic>4
    }
    \\
    {
      \oneVoice
      \tiny
      \override Stem.stencil = ##f
      \override Flag.stencil = ##f
      \override Parentheses.font-size = #0
      <\parenthesize e''>4
    }
  >>
}



