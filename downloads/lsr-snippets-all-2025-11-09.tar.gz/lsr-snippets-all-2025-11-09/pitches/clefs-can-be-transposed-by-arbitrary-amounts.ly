\version "2.22.2"

\header {
  texidoc = "
Clefs can be transposed by arbitrary amounts, not just by octaves.

"
  doctitle = "Clefs can be transposed by arbitrary amounts"
}
\relative c' {
  \clef treble
  c4 c c c
  \clef "treble_8"
  c4 c c c
  \clef "treble_5"
  c4 c c c
  \clef "treble^3"
  c4 c c c
}



