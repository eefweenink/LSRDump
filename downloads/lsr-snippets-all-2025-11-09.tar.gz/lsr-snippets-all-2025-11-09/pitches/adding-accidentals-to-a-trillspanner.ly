\version "2.22.2"

\header {
  texidoc = "
By overriding @code{bound-details}, you can insert an accidental after
the trill sign in a trillspanner. However, this can look ugly since the
accidental isn't aligned.  With a few tweaks to the script size and
position, you can achieve quite pleasing results.

"
  doctitle = "Adding accidentals to a trillspanner"
}
%% http://lsr.di.unimi.it/LSR/Item?id=304

\relative c'' {
  \override TrillSpanner.bound-details.left.text = \markup{ 
    \musicglyph "scripts.trill" \raise #0.65 \teeny  \sharp }
  
  b1\startTrillSpan
  b1\stopTrillSpan
  
  \override TrillSpanner.bound-details.left.text = \markup{ 
    \musicglyph "scripts.trill" \raise #0.65 \teeny  \flat }
  
  c1\startTrillSpan
  c1\stopTrillSpan
}



