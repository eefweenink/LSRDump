\version "2.22.2"

\header {
  texidoc = "
In some cases, ottava text should be on the right for a clearer
reading.

"
  doctitle = "Ottava text on the right"
}
%% => http://lsr.di.unimi.it/LSR/Item?u=1&id=1074
%% Credits PPS on Nov. 2018

\relative c'' {
  \override Staff.OttavaBracket.stencil = #ly:line-spanner::print
  \override Staff.OttavaBracket.bound-details =
    #`((right . ((text . ,#{ \markup " 8va" #})
                 (Y . 0)
                 (attach-dir . ,RIGHT)
                 (padding . 3.5)
                 (stencil-align-dir-y . ,CENTER)))
       (left . ((Y . 0)
                (padding . 0)
                (attach-dir . ,LEFT)
                (text . ,(make-draw-line-markup (cons 0 -1.2))))))

  \override Staff.OttavaBracket.left-bound-info =
     #ly:horizontal-line-spanner::calc-left-bound-info-and-text
  \override Staff.OttavaBracket.right-bound-info =
     #ly:horizontal-line-spanner::calc-right-bound-info
  \ottava #1
  \once\hide
  c1 \glissando
  c''1
} 


