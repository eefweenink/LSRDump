\version "2.22.2"

\header {
  texidoc = "
In music that contains many occurrences of the same sequence of notes
at different pitches, the following music function may prove useful. 
It takes a note, of which only the pitch is used.

This example creates the rhythm used throughout Mars, from Gustav
Holst's The Planets. 

"
  doctitle = "Creating a sequence of notes on various pitches"
}
rhythm =
#(define-music-function (p) (ly:pitch?)
   "Make the rhythm in Mars (the Planets) at the given pitch"
  #{ \tuplet 3/2 { $p 8 8 8 } 4 4 8 8 4 #})

\new Staff {
  \time 5/4
  \rhythm c'
  \rhythm c''
  \rhythm g
}


