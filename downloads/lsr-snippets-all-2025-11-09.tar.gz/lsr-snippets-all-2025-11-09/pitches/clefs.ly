\version "2.22.2"

\header {
  texidoc = "
 The clef indicates which lines of the staff correspond to which
pitches.  The clef is set with the @code{\\clef} command:


         @{ c''2 \\clef alto g'2 @}

 
Supported clefs include:
     
@code{treble, violin, G, G2} G clef on 2nd line @code{alto, C} C clef
on 3rd line @code{tenor} C clef on 4th line.  @code{bass, F} F clef on
4th line @code{french} G clef on 1st line, so-called French violin clef
@code{soprano} C clef on 1st line @code{mezzosoprano} C clef on 2nd
line @code{baritone} C clef on 5th line @code{varbaritone} F clef on
3rd line @code{subbass} F clef on 5th line @code{percussion} percussion
clef @code{tab} tablature clef

 By adding @code{_8} or @code{^8} to the clef name, the clef is
transposed one octave down or up, respectively, and @code{_15} and
@code{^15} transposes by two octaves.  The argument clefname must be
enclosed in quotes when it contains underscores or digits. See the last
two bars for an example. 

"
  doctitle = "Clefs"
}
%% http://lsr.di.unimi.it/LSR/Item?id=173

{ 
  g'2 \clef alto g'2 
  \clef tenor g'2 \clef bass g'2
  \clef french g'2 \clef soprano g'2
  \clef mezzosoprano g'2 \clef baritone g'2
  \clef varbaritone g'2 \clef subbass g'2
  \clef percussion g'2 \clef tab g'2
  
% TO TRANSPOSE THE CLEF ONE OCTAVE UP OR DOWN SEE THE FOLLOWING BARS:
  \clef "G_8" c'1 \clef "G^8" c'1
}



