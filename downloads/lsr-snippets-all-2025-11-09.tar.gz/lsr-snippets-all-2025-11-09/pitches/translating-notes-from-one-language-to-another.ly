\version "2.22.2"

\header {
  texidoc = "
To change an input file written in a foreign language to your favorite
language use @code{\\include \"…language….ly\"} and
@code{\\displayLilyMusic @{ \\melody @}}.


The translation is by default written to the log; you can redirect this
output to a file of your choice using the command @code{lilypond.exe
>yourfile.ly} (with windows).


The result of the snippet will be in absolute pitch:


@{
  c8 d e f g a b c |
  cflat dflat eflat fflat gflat aflat bflat cflat |
  csharp dsharp esharp fsharp gsharp aflat bsharp csharp |
  \\bar \"|.\"
    
@}



"
  doctitle = "Translating notes from one language to another"
}
%% http://lsr.di.unimi.it/LSR/Item?id=638

\include "deutsch.ly"

melody = {
  c8 d e f g a h c |
  ces8 des es fes ges as b ces |
  cis8 dis eis fis gis as his cis |
  \bar "|."
}

\include "english.ly"
\displayLilyMusic { \melody }

\paper { tagline = ##f }

