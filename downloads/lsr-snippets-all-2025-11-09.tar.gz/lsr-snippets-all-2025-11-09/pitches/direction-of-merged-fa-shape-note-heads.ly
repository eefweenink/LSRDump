\version "2.22.2"

\header {
  texidoc = "
Using property @code{NoteCollision.fa-merge-direction}, the direction
of @qq{fa} shape note heads (@qq{fa}, @qq{faThin}, etc.) can be
controlled independently of the stem direction if two voices with the
same pitch and different stem directions are merged.  If this property
is not set, the @qq{down} glyph variant is used.

"
  doctitle = "Direction of merged 'fa' shape note heads"
}
{
  \clef bass

  << { \aikenHeads
       f2
       \override Staff.NoteCollision.fa-merge-direction = #UP
       f2 }
  \\ { \aikenHeads
       f2
       f2 }
  >>
}

