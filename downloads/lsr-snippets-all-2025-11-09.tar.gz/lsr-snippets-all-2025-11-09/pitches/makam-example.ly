\version "2.22.2"

\header {
  texidoc = "
Makam is a type of melody from Turkey using 1/9th-tone microtonal
alterations. Consult the initialization file @samp{ly/makam.ly} for
details of pitch names and alterations. 

"
  doctitle = "Makam example"
}
% Initialize makam settings
\include "makam.ly"

\relative c' {
  \set Staff.keyAlterations = #`((6 . ,(- KOMA)) (3 . ,BAKIYE))
  c4 cc db fk
  gbm4 gfc gfb efk
  fk4 db cc c
}



