\version "2.22.2"

\header {
  texidoc = "
When changing the clef at the beginning of the first measure, Lilypond
just changes the clef for the staff. This is how to keep the staff clef
and add an extra clef after the time signature and before the first
note. 

"
  doctitle = "Clef change at the beginning of a piece (alternative)"
}
% LSR: http://lsr.di.unimi.it/LSR/Item?id=956
%% => http://lilypond.1069038.n5.nabble.com/Clef-change-at-the-beginning-of-a-staff-tc168090.html 
%% see also: http://lsr.di.unimi.it/LSR/Item?id=792

\relative c' {
  %%  Start with a bass clef :
  \clef bass
  %%  Use a hidden grace note:
  \once\hideNotes\grace c64
  %%  Adjust the clef spacing:
  \once\override Staff.Clef.X-extent = #'(1 . 2)
  %%  Put in the treble clef:
  \clef treble
  c4 c c c | c1
}


