\version "2.22.2"

\header {
  texidoc = "
The accidentals engravers engraver usually live at Staff level, but
reads the settings for Accidental at Voice level, so you can
@code{\\override} them at Voice.  To get rid of all accidentals, you
need to remove both the @code{Accidental} engraver and the
@code{AccidentalCautionary} one.

"
  doctitle = "Removing accidentals from a single voice"
}
%% http://lsr.di.unimi.it/LSR/Item?id=758

SampleMusic = { cis cis cis! cis? }

LongMusic = {
  \SampleMusic

  \override Voice.Accidental.stencil = ##f
  \SampleMusic
  
  \override Voice.AccidentalCautionary.stencil = ##f
  \SampleMusic
  
  \revert Voice.Accidental.stencil
  \revert Voice.AccidentalCautionary.stencil
  \SampleMusic
}

<<
  \relative c'' {
    \LongMusic
  }
\\
  \relative c' {
    \SampleMusic
    \SampleMusic
    \SampleMusic
    \SampleMusic
  }
>>



