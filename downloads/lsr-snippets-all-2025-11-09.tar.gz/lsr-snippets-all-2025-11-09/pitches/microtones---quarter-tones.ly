\version "2.22.2"

\header {
  texidoc = "
Half-flats and half-sharps are formed by adding -eh and -ih; the
following is a series of Cs with increasing pitches. Micro tones are
also exported to the MIDI file. There are no generally accepted
standards for denoting three quarter flats, so LilyPond's symbol does
not conform to any standard.

"
  doctitle = "Microtones - quarter tones"
}
%% http://lsr.di.unimi.it/LSR/Item?id=156

\relative c'' {
  ceseh ceh cih cisih 
}



