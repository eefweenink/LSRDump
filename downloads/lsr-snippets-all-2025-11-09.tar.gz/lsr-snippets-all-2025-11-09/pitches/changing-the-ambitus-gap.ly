\version "2.22.2"

\header {
  texidoc = "
It is possible to change the default gap between the ambitus noteheads
and the line joining them.

"
  doctitle = "Changing the ambitus gap"
}
\layout {
  \context {
    \Voice
    \consists "Ambitus_engraver"
  }
}

\new Staff {
  \time 2/4
  % Default setting
  c'4 g''
}

\new Staff {
  \time 2/4
  \override AmbitusLine.gap = 0
  c'4 g''
}

\new Staff {
  \time 2/4
  \override AmbitusLine.gap = 1
  c'4 g''
}

\new Staff {
  \time 2/4
  \override AmbitusLine.gap = 1.5
  c'4 g''
}

\paper { tagline = ##f }

