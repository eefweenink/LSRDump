\version "2.22.2"

\header {
  texidoc = "
Normally accidentals are printed automatically where needed, but it is
also possible to force them to be printed. A reminder accidental can be
forced by adding an exclamation mark after the pitch. A cautionary
accidental (i.e. an accidental within parentheses) can be obtained by
adding a question mark after the pitch.

The size of cautionary accidentals can be changed and the parentheses
removed if required.

Suggested accidentals are a part of ancient music (known as
annotational accidentals) and are printed above the note.  Their size
can also be changed and paretheses added if desired. 

"
  doctitle = "Changing the appearance of forced, cautionary and suggested accidentals"
}
%% http://lsr.di.unimi.it/LSR/Item?id=155


\relative c' {
  cis cis cis! cis?

  cis'4
  \override Staff.AccidentalCautionary.font-size = #-5
  cis?4
  \override Staff.AccidentalCautionary.parenthesized = ##f
  cis?4
  \revert Staff.AccidentalCautionary.font-size
  \revert Staff.AccidentalCautionary.parenthesized
  cis?4

  \set suggestAccidentals = ##t
  cis,4
  \override Staff.AccidentalSuggestion.font-size = #-5
  cis!4
  \override Staff.AccidentalSuggestion.parenthesized = ##t
  cis!4
  \revert Staff.AccidentalSuggestion.font-size
  \revert Staff.AccidentalSuggestion.parenthesized
  cis!4
  \set suggestAccidentals = ##f
  cis!4
}




