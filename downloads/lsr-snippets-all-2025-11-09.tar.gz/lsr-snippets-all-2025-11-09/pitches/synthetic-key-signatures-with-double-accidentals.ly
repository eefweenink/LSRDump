\version "2.22.2"

\header {
  texidoc = "
In some contemporary music, you run into synthetic scales with double
sharps and flats.If you need to display the synthetic key signature,
you can even let DOUBLE-SHARP and DOUBLE-FLAT be printed. 

"
  doctitle = "Synthetic key signatures with double accidentals"
}
synthetic = 
  #`((0 . ,NATURAL) 
     (1 . ,DOUBLE-SHARP) 
     (2 . ,SHARP)
     (3 . ,NATURAL) 
     (4 . ,FLAT) 
     (5 . ,FLAT) 
     (6 . ,DOUBLE-FLAT))

m = \relative c' { \omit Staff.TimeSignature c8 disis eis f ges aes beses c }

<<
  \new Staff \m
  \new Staff { \key c \synthetic \m }
>>


