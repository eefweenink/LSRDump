\version "2.22.2"

\header {
  texidoc = "
The optional octave specification takes the form of a series of single
quote (`'') characters or a series of comma (`,') characters. Each '
raises the pitch by one octave; each , lowers the pitch by an octave

"
  doctitle = "Pitches entry 3 - octaves"
}
%% http://lsr.di.unimi.it/LSR/Item?id=154

{
  c' c'' es' g' 
  as' gisis' ais'
}



