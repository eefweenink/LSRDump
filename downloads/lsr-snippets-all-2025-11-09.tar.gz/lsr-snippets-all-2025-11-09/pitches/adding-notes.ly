\version "2.22.2"

\header {
  texidoc = "
A note is printed by specifying its pitch and then its duration.

    


 

"
  doctitle = "Adding notes"
}
%% http://lsr.di.unimi.it/LSR/Item?id=151

{ cis'4 d'8 e'16 c'16 }



