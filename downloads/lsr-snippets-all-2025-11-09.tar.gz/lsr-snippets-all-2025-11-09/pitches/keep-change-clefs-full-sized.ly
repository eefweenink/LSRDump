\version "2.22.2"

\header {
  texidoc = "
When a clef is changed, the clef sign displayed is smaller than the
initial clef.  This can be overridden with @code{full-size-change}.

"
  doctitle = "Keep change clefs full sized"
}
\relative c' {
  \clef "treble"
  c1
  \clef "bass"
  c1
  \clef "treble"
  c1
  \override Staff.Clef.full-size-change = ##t
  \clef "bass"
  c1
  \clef "treble"
  c1
  \revert Staff.Clef.full-size-change
  \clef "bass"
  c1
  \clef "treble"
  c1
}



