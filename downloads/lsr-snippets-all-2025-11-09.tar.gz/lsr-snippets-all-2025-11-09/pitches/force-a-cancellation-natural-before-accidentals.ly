\version "2.22.2"

\header {
  texidoc = "
The following example shows how to force a natural sign before an
accidental.

"
  doctitle = "Force a cancellation natural before accidentals"
}
\relative c' { 
  \key es \major
  bes c des 
  \tweak Accidental.restore-first ##t 
  eis
}


