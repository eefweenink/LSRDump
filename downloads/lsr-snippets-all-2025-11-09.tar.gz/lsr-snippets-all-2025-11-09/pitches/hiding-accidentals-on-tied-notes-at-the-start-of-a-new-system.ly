\version "2.22.2"

\header {
  texidoc = "
This shows how to hide accidentals on tied notes at the start of a new
system.

"
  doctitle = "Hiding accidentals on tied notes at the start of a new system"
}
\relative c'' {
  \override Accidental.hide-tied-accidental-after-break = ##t
  cis1~ cis~
  \break
  cis
}

\paper { tagline = ##f }

