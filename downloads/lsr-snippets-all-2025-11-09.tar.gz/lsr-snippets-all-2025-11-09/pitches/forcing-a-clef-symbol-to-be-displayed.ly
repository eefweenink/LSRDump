\version "2.22.2"

\header {
  texidoc = "
When a clef sign has already been displayed and it has not been changed
to a different clef, then repeating the @code{\\clef} command will be
ignored by LilyPond, since it is not a change of clef.  It is possible
to force the clef to be redisplayed using the command @code{\\set
Staff.forceClef = ##t}.

"
  doctitle = "Forcing a clef symbol to be displayed"
}
\relative c' {
  \clef treble 
  c1
  \clef treble 
  c1   
  \set Staff.forceClef = ##t
  c1   
  \clef treble 
  c1   
}



