\version "2.22.2"

\header {
  texidoc = "
A chord is formed by a enclosing a set of pitches in < and >. A chord
may be followed by a duration, and a set of articulations, just like
simple notes

"
  doctitle = "Chords entry - simultaneous notes"
}
%% http://lsr.di.unimi.it/LSR/Item?id=157

\relative c' {
  <c e g>4 <c>8
}



