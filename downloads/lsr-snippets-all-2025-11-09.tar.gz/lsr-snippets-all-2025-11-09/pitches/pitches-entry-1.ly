\version "2.22.2"

\header {
  texidoc = "
The notes are specified by the letters a through g. The octave is
formed with notes ranging from c to b. The pitch c is an octave below
middle C and the letters span the octave above that C.

"
  doctitle = "Pitches entry 1"
}
%% http://lsr.di.unimi.it/LSR/Item?id=152

{
  \clef bass
    a,4 b, c d 
    e f g a 
    b c' d' e' 
  \clef treble 
    f' g' a' b' 
    c'' d'' e'' f''
}



