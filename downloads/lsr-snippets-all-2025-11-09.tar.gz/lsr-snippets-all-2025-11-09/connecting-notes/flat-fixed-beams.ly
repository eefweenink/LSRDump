\version "2.22.2"

\header {
  texidoc = "
Flat beams at a fixed position.

"
  doctitle = "Flat fixed beams"
}
%% http://lsr.di.unimi.it/LSR/Item?id=203

% Flat beams at a fixed position.
\layout { indent = #0 }
 { \time 6/4
   c'16 d' e' f'
   c'' d'' e'' f''
   \override Stem.direction = #down
   \override Beam.positions = #'(-6 . -6)
   c'^"override" d' e' f'
   c'' d'' e'' f''
   \override Stem.direction = #up
   \override Beam.positions = #'(6 . 6)
   c'8 d' e'16 f'
   c''32 d'' e'' f''
   \revert Stem.direction
   \revert Beam.positions
   c'16^"revert" d' e' f'
   c'' d'' e'' f''
   c' d' e' f'
   c'' d'' e'' f''
   c'8 d' e'16 f'
   c''32 d'' e'' f''
 }



