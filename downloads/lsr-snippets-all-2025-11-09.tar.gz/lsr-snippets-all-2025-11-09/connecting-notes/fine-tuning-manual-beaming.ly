\version "2.22.2"

\header {
  texidoc = "
By setting the @code{#'beaming} property, it is possible to override
beaming rules. You may preferably want to use @code{\\once} when doing
so, as this property cannot be shared between objects.

"
  doctitle = "Fine-tuning manual beaming"
}
%% http://lsr.di.unimi.it/LSR/Item?id=240


\relative c'' {
  c32[ c
  \once \override Stem.beaming = #(cons (list 1 2) (list 0 2 4))
  c
  \once \override Stem.beaming = #(cons (list 0 2 4) (list 0 1 4))
  c c c]
}



