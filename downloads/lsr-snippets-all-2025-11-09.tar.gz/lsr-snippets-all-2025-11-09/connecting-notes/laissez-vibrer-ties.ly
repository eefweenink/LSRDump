\version "2.22.2"

\header {
  texidoc = "
Laissez vibrer ties have a fixed size. Their formatting can be tuned
using @code{'tie-configuration}. 

"
  doctitle = "Laissez vibrer ties"
}
\relative c' {
  <c e g>4\laissezVibrer r <c f g>\laissezVibrer r
  <c d f g>4\laissezVibrer r <c d f g>4.\laissezVibrer r8

  <c d e f>4\laissezVibrer r
  \override LaissezVibrerTieColumn.tie-configuration
     = #`((-7 . ,DOWN)
          (-5 . ,DOWN)
          (-3 . ,UP)
          (-1 . ,UP))
  <c d e f>4\laissezVibrer r
}



