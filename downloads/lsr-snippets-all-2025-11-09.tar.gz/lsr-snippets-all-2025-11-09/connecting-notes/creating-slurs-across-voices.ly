\version "2.22.2"

\header {
  texidoc = "
In some situations, it may be necessary to create slurs between notes
from different voices. The solution is to add invisible notes to one of
the voices, using @code{\\hideNotes}.


This example is measure 235 of the Ciaconna from Bach's 2nd Partita for
solo violin, BWV 1004. 

"
  doctitle = "Creating slurs across voices"
}
\relative c' {
  <<
    {
      d16( a') s a s a[ s a] s a[ s a]
    }
    \\
    {
      \slurUp
      bes,16[ s e](
      \hideNotes a)
      \unHideNotes f[(
      \hideNotes a)
      \unHideNotes fis](
      \hideNotes a)
      \unHideNotes g[(
      \hideNotes a)
      \unHideNotes gis](
      \hideNotes a)
    }
  >>
}



