\version "2.22.2"

\header {
  texidoc = "
Short tremolos (involving eighth notes or shorter durations) can be
obtained; in such a case only one beam is connected to the stems.

"
  doctitle = "Short tremolos"
}
%% http://lsr.di.unimi.it/LSR/Item?id=241
%% see also http://lsr.di.unimi.it/LSR/Item?id=241

\context Staff \relative c' {
  \repeat "tremolo" 2 { c32 e32 }
  \stemDown
  \repeat "tremolo" 2 { c32 e32 }
}



