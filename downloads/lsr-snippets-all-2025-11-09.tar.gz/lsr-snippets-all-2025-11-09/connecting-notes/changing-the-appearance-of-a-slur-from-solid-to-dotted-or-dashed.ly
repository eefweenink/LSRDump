\version "2.22.2"

\header {
  texidoc = "
The appearance of slurs may be changed from solid to dotted or dashed. 

"
  doctitle = "Changing the appearance of a slur from solid to dotted or dashed"
}
\relative c' {
  c4( d e c)
  \slurDotted
  c4( d e c)
  \slurSolid
  c4( d e c)
  \slurDashed
  c4( d e c)
  \slurSolid
  c4( d e c)
}



