\version "2.22.2"

\header {
  texidoc = "
Between notes, there may be simple glissando lines.  Here, the first
two glissandi are not consecutive.


The engraver does no time-keeping, so it involves some trickery to get
@code{<< @{ s8 s8 s4 @} @{ c4 \\gliss d4 @} >>} working correctly. 

"
  doctitle = "Glissando"
}
%% http://lsr.di.unimi.it/LSR/Item?id=215

\paper { tagline = ##f }

%here starts the snippet:

\layout{
  line-width = 50\mm
  indent = 0
}

\new Staff 
\relative c''{
  \override Glissando.breakable = ##t
  %% gliss non gliss and 
  c4 \glissando d e \glissando f \glissando 
  \break
  %% consecutive 
  c \glissando d, \glissando e'
  << 
    { \stemUp e8 \glissando g8 }
    \context Voice = VB 
    {\stemDown \repeat unfold 4 d16 } 
  >>
  \override Glissando.style = #'zigzag
  c4 \glissando c,, \glissando c' \glissando d
  \break
  \override Glissando.style = #'trill
  c4 \glissando c,, \glissando c' \glissando d
}



