\version "2.22.2"

\header {
  texidoc = "
In mensural ligatures, notes with ancient durations are printed in a
tight manner. 

"
  doctitle = "Mensural ligatures"
}
%% http://lsr.di.unimi.it/LSR/Item?id=118

voice = \transpose c c' {
  \cadenzaOn
  \set Score.measureBarType = #"-"
  g\longa c\breve a\breve f\breve d'\longa^\fermata
  \bar "|"
  \[
  g\longa c\breve a\breve f\breve d'\longa^\fermata
  \]
  \bar "|"
  e1 f1 a\breve g\longa^\fermata
  \bar "|"
  \[
  e1 f1 a\breve g\longa^\fermata
  \]
  \bar "|"
  e1 f1 a\breve g\longa^\fermata
  \bar "||"
}

\score {
  \context ChoirStaff <<
    \new MensuralStaff {
      \context MensuralVoice \voice
    }
    \new Staff {
      \context Voice \voice
    }
  >>
}

\paper { tagline = ##f }

