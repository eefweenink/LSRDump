\version "2.22.2"

\header {
  texidoc = "
By setting the minimum length of a slur, notes are more separated.  

"
  doctitle = "Setting the minimum length of a slur to separate notes"
}
%% http://lsr.di.unimi.it/LSR/Item?id=135

\score{
  \relative c''{
    \time 2/4
    \override Slur.minimum-length = #40
    c( c)
    c~ c\break
  }
}



