\version "2.22.2"

\header {
  texidoc = "
The layout of the major 7 can be tuned with @code{majorSevenSymbol}. 

"
  doctitle = "chord name major7"
}
\chords {
  c:7+
  \set majorSevenSymbol = \markup { j7 }
  c:7+
}



