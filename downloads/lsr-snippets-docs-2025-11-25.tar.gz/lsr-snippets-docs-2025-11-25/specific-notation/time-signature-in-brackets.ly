\version "2.22.2"

\header {
  texidoc = "
The time signature can be enclosed within brackets.

"
  doctitle = "Time signature in brackets"
}
\relative c'' {
  \override Staff.TimeSignature.stencil = #(lambda (grob)
    (bracketify-stencil (ly:time-signature::print grob) Y 0.1 0.2 0.1))
  \time 2/4
  a4 b8 c
}



