\version "2.22.2"

\header {
  texidoc = "
Enclose the time signature in parentheses.

"
  doctitle = "Time signature in parentheses"
}
\relative c'' {
  \override Staff.TimeSignature.stencil = #(lambda (grob)
    (parenthesize-stencil (ly:time-signature::print grob) 0.1 0.4 0.4 0.1))
  \time 2/4
  a4 b8 c
}



