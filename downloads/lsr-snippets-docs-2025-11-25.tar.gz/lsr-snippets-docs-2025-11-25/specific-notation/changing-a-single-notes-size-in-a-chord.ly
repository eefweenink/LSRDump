\version "2.22.2"

\header {
  texidoc = "
Individual note heads in a chord can be modified with the
@code{\\tweak} command inside a chord, by altering the @code{font-size}
property.


Inside the chord (within the brackets @code{< >}), before the note to
be altered, place the @code{\\tweak} command, followed by
@code{font-size} and define the proper size like @code{#-2} (a tiny
note head).



"
  doctitle = "Changing a single note's size in a chord"
}
\relative c' {
  <\tweak font-size #+2 c e g c
   \tweak font-size #-2 e>1
   ^\markup { A tiny e }_\markup { A big c }
}



