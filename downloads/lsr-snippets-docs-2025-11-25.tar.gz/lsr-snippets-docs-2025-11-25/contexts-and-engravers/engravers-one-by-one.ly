\version "2.22.2"

\header {
  texidoc = "
The notation problem, creating a certain symbol, is handled by plugins.
 Each plugin is called an engraver. In this example, (some) engravers
are switched on one by one, in the following order:

- note heads,


- staff symbol,


- clef,


- stem,


- beams, slurs, accents,


- accidentals, bar lines, time signature and key signature.



Engravers are grouped. For example, note heads, slurs, beams, etc.,
form a @code{Voice} context. Engravers for key signature, accidentals,
bar line, etc., form a @code{Staff} context. 

"
  doctitle = "Engravers one-by-one"
}
\header { tagline = ##f }

topVoice = \relative c' {
  \key d \major
  es8([ g] a[ fis])
  b4
  b16[-. b-. b-. cis-.]
  d4->
}


% empty staff and voice contexts
MyStaff = \context {
  \type Engraver_group
  \name Staff

  \accepts Voice
  \defaultchild Voice
}
MyVoice = \context {
  \type Engraver_group
  \name Voice
}


% add note heads
MyVoice = \context {
  \MyVoice
  \consists Note_heads_engraver
}
\score {
  \topVoice
  \layout {
    \context { \MyStaff }
    \context { \MyVoice }
  }
}

% add staff
MyStaff = \context {
  \MyStaff
  \consists Staff_symbol_engraver
}
\score {
  \topVoice
  \layout {
    \context { \MyStaff }
    \context { \MyVoice }
  }
}

% add clef
MyStaff = \context {
  \MyStaff
  \consists Clef_engraver
}
\score {
  \topVoice
  \layout {
    \context { \MyStaff }
    \context { \MyVoice }
  }
}

% add stems
MyVoice = \context {
  \MyVoice
  \consists Stem_engraver
}
\score {
  \topVoice
  \layout {
    \context { \MyStaff }
    \context { \MyVoice }
  }
}

% add beams, slurs, and accents
MyVoice = \context {
  \MyVoice
  \consists Beam_engraver
  \consists Slur_engraver
  \consists Script_engraver
  \consists Rhythmic_column_engraver
}
\score {
  \topVoice
  \layout {
    \context { \MyStaff }
    \context { \MyVoice }
  }
}

% add accidentals, bar, time signature, and key signature
MyStaff = \context {
  \MyStaff
  \consists Accidental_engraver
  \consists Bar_engraver
  \consists Time_signature_engraver
  \consists Key_engraver
}
\score {
  \topVoice
  \layout {
    \context { \MyStaff }
    \context { \MyVoice }
  }
}

