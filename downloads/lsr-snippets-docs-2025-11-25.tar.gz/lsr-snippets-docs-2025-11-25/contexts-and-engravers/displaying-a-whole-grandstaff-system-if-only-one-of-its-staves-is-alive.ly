\version "2.22.2"

\header {
  texidoc = "
In orchestral scores sometimes single or groups of instruments are
silent for a while and their staves can be removed for that time (with
@code{\\removeEmptyStaves}).


When they play again it is often preferred to show the staves of all
instruments of such a group.  This can be done adding the
@code{Keep_alive_together_engraver} in the grouper (e.g., a GrandStaff
or a StaffGroup).


In the example the violins are silent in the 2nd system and in the 3rd
system. Only the first violin plays the last measure but the staff of
the second violin is also displayed. 

"
  doctitle = "Displaying a whole GrandStaff system if only one of its staves is alive"
}
\score {
  <<
    \new StaffGroup = "StaffGroup_woodwinds"
    <<
      \new Staff = "Staff_flute" \with {
        instrumentName = "Flute" 
        shortInstrumentName = "Fl"
      } 
      \relative c' { 
        \repeat unfold 3 { c'4 c c c | c c c c | c c c c | \break }
      }
    >>
    \new StaffGroup = "StaffGroup_Strings"
    <<
      \new GrandStaff = "GrandStaff_violins"
      <<
        \new Staff = "StaffViolinI" \with { 
          instrumentName = "Violin I" 
          shortInstrumentName = "Vi I"
        }
        \relative c'' {
          a1 \repeat unfold 7 { s1 } \repeat unfold 12 a16  a4
        }
        \new Staff = "StaffViolinII" \with { 
          instrumentName = "Violin II" 
          shortInstrumentName = "Vi II"
        }
        \relative c' { e1 \repeat unfold 8 { s1 } }
      >>
      \new Staff = "Staff_cello" \with { 
        instrumentName = "Cello" 
        shortInstrumentName = "Ce"
      }
      \relative c { \clef bass \repeat unfold 9 { c1 }}
    >>
  >>
}

\paper { tagline = ##f }

\layout {
  indent = 3.0\cm
  short-indent = 1.5\cm
  \context {
    \GrandStaff
    \consists Keep_alive_together_engraver
  }
  \context {
    \Staff
    \RemoveEmptyStaves
  }
}



