\version "2.22.2"

\header {
  texidoc = "
An extra staff can be added (possibly temporarily) after the start of a
piece. 

"
  doctitle = "Adding an extra staff"
}
\score {
  <<
    \new Staff \relative c'' {
      c1 | c | c | c | c
    }
    \new StaffGroup \relative c'' {
      \new Staff {
        c1 | c
        <<
          {
            c1 | d
          }
          \new Staff {
            \once \omit Staff.TimeSignature
            c1 | b
          }
        >>
        c1
      }
    }
  >>
}




