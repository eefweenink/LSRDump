\version "2.22.2"

\header {
  texidoc = "
Some dynamics may involve text indications (such as @qq{più forte} or
@qq{piano subito}). These can be produced using a @code{\\markup}
block.

"
  doctitle = "Combining dynamics with markup texts"
}
piuF = \markup { \italic più \dynamic f }

\layout { ragged-right = ##f }

\relative c'' {
  c2\f c-\piuF
}



