\version "2.22.2"

\header {
  texidoc = "
Slurs can be made asymmetric to match an asymmetric pattern of notes
better.

"
  doctitle = "Asymmetric slurs"
}
slurNotes = { d,8( a' d f a f' d, a) }

\relative c' {
  \stemDown
  \slurUp
  \slurNotes
  \once \override Slur.eccentricity = #3.0
  \slurNotes
}



