\version "2.22.2"

\header {
  texidoc = "
Hairpin dynamics may be printed with a circled tip (@qq{al niente}
notation) by setting the @code{circled-tip} property of the
@code{Hairpin} object to @code{#t}. 

"
  doctitle = "Printing hairpins using al niente notation"
}
\relative c'' {
  \override Hairpin.circled-tip = ##t
  c2\< c\!
  c4\> c\< c2\!
}



