\version "2.22.2"

\header {
  texidoc = "
The @code{shortest-duration-space} property may be tweaked to adjust
the shape of falls and doits.

"
  doctitle = "Adjusting the shape of falls and doits"
}
\relative c'' {
  \override Score.SpacingSpanner.shortest-duration-space = 4.0
  c2-\bendAfter 5
  c2-\bendAfter -4.75
  c2-\bendAfter 8.5
  c2-\bendAfter -6
}



