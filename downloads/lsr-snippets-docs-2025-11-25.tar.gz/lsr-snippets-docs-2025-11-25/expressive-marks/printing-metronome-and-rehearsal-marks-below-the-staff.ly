\version "2.22.2"

\header {
  texidoc = "
By default, metronome and rehearsal marks are printed above the staff. 
To place them below the staff simply set the @code{direction} property
of @code{MetronomeMark} or @code{RehearsalMark} appropriately.

"
  doctitle = "Printing metronome and rehearsal marks below the staff"
}
\layout { 
  indent = 0
  ragged-right = ##f 
}

{
  % Metronome marks below the staff 
  \override Score.MetronomeMark.direction = #DOWN
  \tempo 8. = 120
  c''1

  % Rehearsal marks below the staff
  \override Score.RehearsalMark.direction = #DOWN
  \mark \default
  c''1
}



