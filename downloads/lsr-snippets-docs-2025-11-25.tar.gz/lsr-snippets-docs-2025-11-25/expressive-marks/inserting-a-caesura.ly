\version "2.22.2"

\header {
  texidoc = "
Caesura marks can be created by overriding the @code{'text} property of
the @code{BreathingSign} object. A curved caesura mark is also
available. 

"
  doctitle = "Inserting a caesura"
}
\relative c'' {
  \override BreathingSign.text = \markup {
    \musicglyph "scripts.caesura.straight"
  }
  c8 e4. \breathe g8. e16 c4

  \override BreathingSign.text = \markup {
    \musicglyph "scripts.caesura.curved"
  }
  g8 e'4. \breathe g8. e16 c4
}



