\version "2.22.2"

\header {
  texidoc = "
@code{NoteColumn} grobs can be skipped over by glissandi.

"
  doctitle = "Glissandi can skip grobs"
}
\relative c' {
  a2 \glissando
  \once \override NoteColumn.glissando-skip = ##t
  f''4 d,
}


