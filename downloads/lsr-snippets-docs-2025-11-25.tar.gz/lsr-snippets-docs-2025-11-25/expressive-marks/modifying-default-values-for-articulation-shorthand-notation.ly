\version "2.22.2"

\header {
  texidoc = "
The shorthands are defined in @samp{ly/script-init.ly}, where the
variables @code{dashHat}, @code{dashPlus}, @code{dashDash},
@code{dashBang}, @code{dashLarger}, @code{dashDot}, and
@code{dashUnderscore} are assigned default values.  The default values
for the shorthands can be modified. For example, to associate the
@code{-+} (@code{dashPlus}) shorthand with the trill symbol instead of
the default + symbol, assign the value @code{\\trill} to the variable
@code{dashPlus}: 

"
  doctitle = "Modifying default values for articulation shorthand notation"
}
\paper { tagline = ##f }

\relative c'' { c1-+ }

dashPlus = \trill

\relative c'' { c1-+ }

