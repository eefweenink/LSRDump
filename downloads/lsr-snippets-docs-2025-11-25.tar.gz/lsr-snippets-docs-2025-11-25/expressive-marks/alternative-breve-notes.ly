\version "2.22.2"

\header {
  texidoc = "
Breve notes are also available with two vertical lines on each side of
the notehead instead of one line and in baroque style.

"
  doctitle = "Alternative breve notes"
}
\relative c'' {
  \time 4/2
  c\breve | 
  \override Staff.NoteHead.style = #'altdefault
  b\breve
  \override Staff.NoteHead.style = #'baroque
  b\breve
  \revert Staff.NoteHead.style
  a\breve
}



