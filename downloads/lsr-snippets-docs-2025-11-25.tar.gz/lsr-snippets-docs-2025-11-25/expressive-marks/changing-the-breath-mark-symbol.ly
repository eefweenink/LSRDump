\version "2.22.2"

\header {
  texidoc = "
The glyph of the breath mark can be tuned by overriding the @code{text}
property of the @code{BreathingSign} layout object with any markup
text. 

"
  doctitle = "Changing the breath mark symbol"
}
\relative c'' {
  c2
  \override BreathingSign.text = 
    \markup { \musicglyph "scripts.rvarcomma" }
  \breathe
  d2
}



