\version "2.22.2"

\header {
  texidoc = "
Cross-staff arpeggios can be created in contexts other than
@code{GrandStaff} and its derived siblings (@code{PianoStaff},
@code{ChoirStaff}, and @code{StaffGroup}) if the
@code{Span_arpeggio_engraver} is included in the @code{Score} context. 

"
  doctitle = "Creating cross-staff arpeggios in other contexts"
}
<<
  \new PianoStaff <<
    \new Voice \relative c' {
      <c e>2\arpeggio <d f>2\arpeggio
      <c e>1\arpeggio
    }
    \new Voice \relative c {
      \clef bass
      <c g'>2\arpeggio <b g'>2\arpeggio
      <c g'>1\arpeggio
    }
  >>

  \new Staff \relative c {
    \set Score.connectArpeggios = ##t
    \clef bass
    c2\arpeggio g\arpeggio
    c1\arpeggio
  }
>>

\layout {
  \context {
    \Score
    \consists "Span_arpeggio_engraver"
  }
}

