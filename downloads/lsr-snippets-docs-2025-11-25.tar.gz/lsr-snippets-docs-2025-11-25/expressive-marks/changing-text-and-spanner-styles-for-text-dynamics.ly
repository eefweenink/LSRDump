\version "2.22.2"

\header {
  texidoc = "
The text used for crescendos and decrescendos can be changed by
modifying the context properties @code{crescendoText} and
@code{decrescendoText}.

The style of the spanner line can be changed by modifying the
@code{'style} property of @code{DynamicTextSpanner}.  The default value
is @code{'dashed-line}, and other possible values include @code{'line},
@code{'dotted-line} and @code{'none}. 

"
  doctitle = "Changing text and spanner styles for text dynamics"
}
\relative c'' {
  \set crescendoText = \markup { \italic { cresc. poco } }
  \set crescendoSpanner = #'text
  \override DynamicTextSpanner.style = #'dotted-line
  a2\< a
  a2 a
  a2 a
  a2 a\mf
}



