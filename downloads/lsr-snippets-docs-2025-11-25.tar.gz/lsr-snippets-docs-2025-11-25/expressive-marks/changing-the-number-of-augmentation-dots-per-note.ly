\version "2.22.2"

\header {
  texidoc = "
The number of augmentation dots on a single note can be changed
independently of the dots placed after the note.

"
  doctitle = "Changing the number of augmentation dots per note"
}
\relative c' {
  c4.. a16 r2 |
  \override Dots.dot-count = 4
  c4.. a16 r2 |
  \override Dots.dot-count = 0
  c4.. a16 r2 |
  \revert Dots.dot-count
  c4.. a16 r2 |
}



