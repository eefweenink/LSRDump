\version "2.22.2"

\header {
  texidoc = "
Skipped beats in very long glissandi are sometimes indicated by timing
marks, often consisting of stems without noteheads.  Such stems can
also be used to carry intermediate expression markings.


If the stems do not align well with the glissando, they may need to be
repositioned slightly. 

"
  doctitle = "Adding timing marks to long glissandi"
}
glissandoSkipOn = {
  \override NoteColumn.glissando-skip = ##t
  \hide NoteHead
  \override NoteHead.no-ledgers = ##t
}

glissandoSkipOff = {
  \revert NoteColumn.glissando-skip
  \undo \hide NoteHead
  \revert NoteHead.no-ledgers
}

\relative c'' {
  r8 f8\glissando
  \glissandoSkipOn
  f4 g a a8\noBeam
  \glissandoSkipOff
  a8

  r8 f8\glissando
  \glissandoSkipOn
  g4 a8
  \glissandoSkipOff
  a8 |

  r4 f\glissando \<
  \glissandoSkipOn
  a4\f \>
  \glissandoSkipOff
  b8\! r |
}


