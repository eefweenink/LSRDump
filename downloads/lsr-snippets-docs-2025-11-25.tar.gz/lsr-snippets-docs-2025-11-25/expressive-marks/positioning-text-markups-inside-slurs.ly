\version "2.22.2"

\header {
  texidoc = "
Text markups need to have the @code{outside-staff-priority} property
set to false in order to be printed inside slurs. 

"
  doctitle = "Positioning text markups inside slurs"
}
\relative c'' {
  \override TextScript.avoid-slur = #'inside
  \override TextScript.outside-staff-priority = ##f
  c2(^\markup { \halign #-10 \natural } d4.) c8
}



