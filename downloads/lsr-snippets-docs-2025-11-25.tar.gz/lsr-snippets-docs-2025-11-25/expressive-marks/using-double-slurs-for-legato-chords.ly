\version "2.22.2"

\header {
  texidoc = "
Some composers write two slurs when they want legato chords.  This can
be achieved by setting @code{doubleSlurs}. 

"
  doctitle = "Using double slurs for legato chords"
}
\relative c' {
  \set doubleSlurs = ##t
  <c e>4( <d f> <c e> <d f>)
}



