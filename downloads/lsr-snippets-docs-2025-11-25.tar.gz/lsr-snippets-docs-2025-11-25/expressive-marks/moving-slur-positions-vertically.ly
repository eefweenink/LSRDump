\version "2.22.2"

\header {
  texidoc = "
The vertical position of a slur can be adjusted using the
@code{positions} property of @code{Slur}.  The property has 2
parameters, the first referring to the left end of the slur and the
second to the right.  The values of the parameters are not used by
LilyPond to make an exact movement of the slur - instead it selects
what placement of the slur looks best, taking into account the
parameter values.  Positive values move the slur up, and are
appropriate for notes with stems down.  Negative values move downward
slurs further down.

"
  doctitle = "Moving slur positions vertically"
}
\relative c' {
  \stemDown
  e4( a)
  \override Slur.positions = #'(1 . 1)
  e4( a)
  \override Slur.positions = #'(2 . 2)
  e4( a)
  \override Slur.positions = #'(3 . 3)
  e4( a)
  \override Slur.positions = #'(4 . 4)
  e4( a)
  \override Slur.positions = #'(5 . 5)
  e4( a)
  \override Slur.positions = #'(0 . 5)
  e4( a)
  \override Slur.positions = #'(5 . 0)
  e4( a)
  \stemUp
  \override Slur.positions = #'(-5 . -5)
  e4( a)
  \stemDown
  \revert Slur.positions
  e4( a)
}



