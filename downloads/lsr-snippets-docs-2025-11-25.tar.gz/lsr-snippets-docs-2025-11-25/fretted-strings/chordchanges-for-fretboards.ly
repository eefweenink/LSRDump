\version "2.22.2"

\header {
  texidoc = "
FretBoards can be set to display only when the chord changes or at the
beginning of a new line.

"
  doctitle = "ChordChanges for FretBoards"
}
\include "predefined-guitar-fretboards.ly"

\paper { tagline = ##f }

myChords = \chordmode {
  c1 c1 \break
  \set chordChanges = ##t
  c1 c1 \break
  c1 c1
}

<<
  \new ChordNames { \myChords }
  \new FretBoards { \myChords }
  \new Staff { \myChords }
>>



