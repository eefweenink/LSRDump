\version "2.22.2"

\header {
  texidoc = "
This example combines left-hand fingering, string indications, and
right-hand fingering.

"
  doctitle = "Fingerings, string indications, and right-hand fingerings"
}
#(define RH rightHandFinger)

\relative c {
  \clef "treble_8"
  <c-3\5\RH 1 >4
  <e-2\4\RH 2 >4
  <g-0\3\RH 3 >4
  <c-1\2\RH 4 >4
}



