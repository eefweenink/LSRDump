\version "2.22.2"

\header {
  texidoc = "
When using hammer-on or pull-off with chorded notes, only a single arc
is drawn. However @qq{double arcs} are possible by setting the
@code{doubleSlurs} property to @code{#t}.

"
  doctitle = "Hammer on and pull off using chords"
}
\new TabStaff {
  \relative c' {
    % chord hammer-on and pull-off
    \set doubleSlurs = ##t
    <g' b>8( <a c> <g b>)
  }
}


