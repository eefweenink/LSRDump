\version "2.22.2"

\header {
  texidoc = "
Unlike glissandos, slides may go from an imprecise point of the
fretboard to a specific fret. A good way to do this is to add a hidden
grace note before the note which is actually played, as demonstrated in
the following example.

"
  doctitle = "Guitar slides"
}
%% Hide fret number: useful to draw slide into/from a casual point of
%% the fretboard.

hideFretNumber = {
  \once \hide TabNoteHead
  \once \hide NoteHead
  \once \hide Stem
  \once \override NoteHead.no-ledgers = ##t
  \once \override Glissando.bound-details.left.padding = #0.3
}

music= \relative c' {
  \grace { \hideFretNumber d8\2 \glissando s2 } g2\2
  \grace { \hideFretNumber g8\2 \glissando s2 } d2 |

  \grace { \hideFretNumber c,8 \glissando s } f4\5^\markup \tiny { Slide into }
  \grace { \hideFretNumber f8 \glissando s } a4\4
  \grace { \hideFretNumber e'8\3 \glissando s } b4\3^\markup \tiny { Slide from }
  \grace { \hideFretNumber b'8 \glissando s2 } g4 |
}

\score {
  <<
    \new Staff {
      \clef "G_8"
      \music
    }
    \new TabStaff {
      \music
    }
  >>
}

\paper { tagline = ##f }

