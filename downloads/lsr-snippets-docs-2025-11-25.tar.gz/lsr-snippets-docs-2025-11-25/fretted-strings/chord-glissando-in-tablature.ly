\version "2.22.2"

\header {
  texidoc = "
Slides for chords are indicated by default in both @code{Staff} and
@code{TabStaff}. String numbers may be necessary for @code{TabStaff}
because automatic string calculations are different for chords and for
single notes. 

"
  doctitle = "Chord glissando in tablature"
}
myMusic = \relative c' {
  <c e g>1 \glissando <f a c>
  <cis, eis gis>1 \glissando <f a c>
  <cis eis gis>1 \glissando <f a c\3>
}

\score {
  <<
    \new Staff {
      \clef "treble_8"
      \omit StringNumber
      \myMusic
    }
    \new TabStaff \myMusic
  >>
}

\score {
  <<
    \new Staff {
      \clef "treble_8"
      \omit StringNumber
      \myMusic
    }
    \new TabStaff \with { \override Glissando.style = #'none } {
      \myMusic
    }
  >>
}

\paper { tagline = ##f }

