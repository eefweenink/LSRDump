\version "2.22.2"

\header {
  texidoc = "
Fingering instructions can be entered using a simple syntax.

"
  doctitle = "Adding fingerings to a score"
}
\relative c'' {
  c4-1 d-2 f-4 e-3
}



