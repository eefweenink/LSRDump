\version "2.22.2"

\header {
  texidoc = "
By default markups does not show in a tablature. To make them appear,
simply use the command @code{\\revert TabStaff.TextScript.stencil} 

"
  doctitle = "Adding markups in a tablature"
}
%% http://lsr.di.unimi.it/LSR/Item?id=919
% by P.P.Schneider on June 2014

high  = { r4 r8 <g c'> q r8 r4 }

low = { c4 r4 c8 r8 g,8 b, }

pulse = { s8^"1" s^"&" s^"2" s^"&" s^"3" s^"&" s^"4" s^"&" }

\score {
 \new TabStaff {
   \repeat unfold 2 << \high \\ \low \\ \pulse >>
  }
  \layout {
    \context {
      \TabStaff
      \clef moderntab
      \revert TextScript.stencil
      \override TextScript.font-series = #'bold
      \override TextScript.font-size = #-2
      \override TextScript.color = #red
      
    }
    \context {
      \Score
      proportionalNotationDuration = #(ly:make-moment 1/8)
    }
  }
}



