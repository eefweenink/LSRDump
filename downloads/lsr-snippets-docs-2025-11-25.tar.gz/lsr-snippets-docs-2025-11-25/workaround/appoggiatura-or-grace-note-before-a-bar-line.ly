\version "2.22.2"

\header {
  texidoc = "
By default, appoggiaturas and grace notes that occur on the first beat
of a measure are printed after the bar line.  They can however be
printed before, simply by adding an invisible BarLine and then the
visible one, as demonstrated here.

"
  doctitle = "Appoggiatura or grace note before a bar line"
}
{
  R1
  %% default
  \appoggiatura d''8 c''4 r2.
  %% cheated
  \appoggiatura { \bar "" d''8 \bar "|" } c''4 r2.
}



