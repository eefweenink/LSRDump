\version "2.22.2"

\header {
  texidoc = "
This snippet provides a workaround for emitting measure counters using
transparent percent repeats. 

"
  doctitle = "Measure counter"
}
<<
  \context Voice = "foo" {
    \clef bass
    c4 r g r
    c4 r g r
    c4 r g r
    c4 r g r
  }
  \context Voice = "foo" {
    \set countPercentRepeats = ##t
    \hide PercentRepeat
    \override PercentRepeatCounter.staff-padding = #1
    \repeat percent 4 { s1 }
  }
>>



