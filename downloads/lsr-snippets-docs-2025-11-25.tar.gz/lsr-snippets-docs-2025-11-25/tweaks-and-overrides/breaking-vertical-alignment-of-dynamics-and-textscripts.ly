\version "2.22.2"

\header {
  texidoc = "
By default, LilyPond uses @code{DynamicLineSpanner} grobs to vertically
align successive dynamic objects like hairpins and dynamic text. 
However, this is not always wanted.  By inserting
@code{\\breakDynamicSpan}, which ends the alignment spanner
prematurely, this vertical alignment can be avoided. 

"
  doctitle = "Breaking vertical alignment of dynamics and textscripts"
}
{ g1\< |
  e''\f\> |
  c'\p }

{ g1\< |
  e''\breakDynamicSpan\f\> |
  c'\p }

\paper { tagline = ##f }

