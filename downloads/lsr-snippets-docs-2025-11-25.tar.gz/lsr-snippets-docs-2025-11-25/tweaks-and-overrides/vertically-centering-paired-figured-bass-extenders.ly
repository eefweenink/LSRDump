\version "2.22.2"

\header {
  texidoc = "
Where figured bass extender lines are being used by setting
@code{useBassFigureExtenders} to true, pairs of congruent figured bass
extender lines are vertically centered if
@code{figuredBassCenterContinuations} is set to true.

"
  doctitle = "Vertically centering paired figured bass extenders"
}
<<
  \relative c' {
    c8 c b b a a c16 c b b  
    c8 c b b a a c16 c b b  
    c8 c b b a a c c b b
  }
  \figures {
    \set useBassFigureExtenders = ##t
    <6+ 4 3>4 <6 4 3>8 r
    <6+ 4 3>4 <6 4 3>8 <4 3+>16 r
    \set figuredBassCenterContinuations = ##t
    <6+ 4 3>4 <6 4 3>8 r
    <6+ 4 3>4 <6 4 3>8 <4 3+>16 r
    \set figuredBassCenterContinuations = ##f
    <6+ 4 3>4 <6 4 3>8 r
    <6+ 4 3>4 <6 4 3>8 <4 3+>8
  } 
>>



