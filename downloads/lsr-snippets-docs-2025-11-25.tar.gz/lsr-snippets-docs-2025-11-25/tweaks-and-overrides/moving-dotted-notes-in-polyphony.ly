\version "2.22.2"

\header {
  texidoc = "
When a dotted note in the upper voice is moved to avoid a collision
with a note in another voice, the default is to move the upper note to
the right.  This behaviour can be over-ridden by using the
@code{prefer-dotted-right} property of @code{NoteCollision}.

"
  doctitle = "Moving dotted notes in polyphony"
}
\new Staff \relative c' <<
  { 
    f2. f4
    \override Staff.NoteCollision.prefer-dotted-right = ##f
    f2. f4
    \override Staff.NoteCollision.prefer-dotted-right = ##t
    f2. f4
  }
  \\
  { e4 e e e e e e e e e e e }
>>



