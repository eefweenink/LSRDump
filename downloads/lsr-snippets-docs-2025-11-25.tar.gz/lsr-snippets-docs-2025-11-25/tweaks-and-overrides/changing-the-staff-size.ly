\version "2.22.2"

\header {
  texidoc = "
Though the simplest way to resize staves is to use
@code{#(set-global-staff-size xx)}, an individual staff's size can be
changed by scaling the properties @code{'staff-space} and
@code{fontSize}. 

"
  doctitle = "Changing the staff size"
}
<<
  \new Staff {
    \relative c'' {
      \dynamicDown
      c8\ff c c c c c c c
    }
  }
  \new Staff \with {
    fontSize = #-3
    \override StaffSymbol.staff-space = #(magstep -3)
  } {
    \clef bass
    c8 c c c c\f c c c
  }
>>



