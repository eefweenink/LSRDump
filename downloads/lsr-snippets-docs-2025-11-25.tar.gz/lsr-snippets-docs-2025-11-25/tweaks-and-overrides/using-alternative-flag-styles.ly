\version "2.22.2"

\header {
  texidoc = "
Alternative styles of flag on eighth and shorter notes can be displayed
by overriding the @code{stencil} property of @code{Flag}.  Valid values
are @code{modern-straight-flag}, @code{old-straight-flag} and
@code{flat-flag}.

"
  doctitle = "Using alternative flag styles"
}
testnotes = {
  \autoBeamOff
  c8 d16 c32 d64 \acciaccatura { c8 } d64 r4
}

\score {
  \relative c' {
    \time 2/4
    \testnotes
  
    \override Flag.stencil = #modern-straight-flag
    \testnotes
  
    \override Flag.stencil = #old-straight-flag
    \testnotes
  
    \override Flag.stencil = #flat-flag
    \testnotes
  
    \revert Flag.stencil
    \testnotes
  }
  \layout {
    indent = 0
    \context {
      \Score
      \override NonMusicalPaperColumn.line-break-permission = ##f
    }
  }
}



