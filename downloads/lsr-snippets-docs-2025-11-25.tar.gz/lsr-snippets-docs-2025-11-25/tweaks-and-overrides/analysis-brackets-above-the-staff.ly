\version "2.22.2"

\header {
  texidoc = "
Simple horizontal analysis brackets are added below the staff by
default. The following example shows a way to place them above the
staff instead.

"
  doctitle = "Analysis brackets above the staff"
}
\layout {
  \context {
    \Voice
    \consists "Horizontal_bracket_engraver"
  }
}

\relative c'' {
  \once \override HorizontalBracket.direction = #UP
  c2\startGroup
  d2\stopGroup
}



