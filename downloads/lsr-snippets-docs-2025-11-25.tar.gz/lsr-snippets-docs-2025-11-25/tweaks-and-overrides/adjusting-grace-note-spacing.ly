\version "2.22.2"

\header {
  texidoc = "
The space given to grace notes can be adjusted using the
@code{spacing-increment} property of @code{Score.GraceSpacing}.

"
  doctitle = "Adjusting grace note spacing"
}
graceNotes = {
  \grace { c4 c8 c16 c32 }
  c8
}

\relative c'' {
  c8
  \graceNotes
  \override Score.GraceSpacing.spacing-increment = #2.0
  \graceNotes
  \revert Score.GraceSpacing.spacing-increment
  \graceNotes
}



