\version "2.22.2"

\header {
  texidoc = "
System separators can be inserted between systems.  Any markup can be
used, but @code{\\slashSeparator} has been provided as a sensible
default.

"
  doctitle = "Setting system separators"
}
\paper {
  system-separator-markup = \slashSeparator
  line-width = 120
  tagline = ##f
}

notes = \relative c' {
  c1 | c \break
  c1 | c \break
  c1 | c
}

\book {
  \score {
    \new GrandStaff <<
      \new Staff \notes 
      \new Staff \notes 
    >>
  }
}



