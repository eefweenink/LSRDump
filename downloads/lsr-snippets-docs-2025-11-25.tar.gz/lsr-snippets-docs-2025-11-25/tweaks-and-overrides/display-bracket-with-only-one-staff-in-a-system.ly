\version "2.22.2"

\header {
  texidoc = "
If there is only one staff in one of the staff types @code{ChoirStaff}
or @code{StaffGroup}, by default the bracket and the starting bar line
will not be displayed.  This can be changed by overriding
@code{collapse-height} to set its value to be less than the number of
staff lines in the staff.


Note that in contexts such as @code{PianoStaff} and @code{GrandStaff}
where the systems begin with a brace instead of a bracket, another
property has to be set, as shown on the second system in the example. 

"
  doctitle = "Display bracket with only one staff in a system"
}
\score {
  \new StaffGroup <<
    % Must be lower than the actual number of staff lines
    \override StaffGroup.SystemStartBracket.collapse-height = 4
    \override Score.SystemStartBar.collapse-height = 4
    \new Staff {
      c'1
    }
  >>
}
\score {
  \new PianoStaff <<
    \override PianoStaff.SystemStartBrace.collapse-height = 4
    \override Score.SystemStartBar.collapse-height = 4
    \new Staff {
      c'1
    }
  >>
}

\paper { tagline = ##f }



