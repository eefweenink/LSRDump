\version "2.22.2"

\header {
  texidoc = "
In @qq{simple} lead-sheets, sometimes no actual notes are written,
instead only @qq{rhythmic patterns} and chords above the measures are
notated giving the structure of a song. Such a feature is for example
useful while creating/transcribing the structure of a song and also
when sharing lead sheets with guitarists or jazz musicians.



"
  doctitle = "Rhythmic slashes"
}
startPat = {
  \improvisationOn
  \omit Stem
}
stopPat = {
  \improvisationOff
  \undo \omit Stem
}

\new Voice \with {
  \consists Pitch_squash_engraver
} {
  c'4 d' e' f' |
  \startPat
  4 4 4 4 |
  \stopPat
  f'4 e' d' c'
}

