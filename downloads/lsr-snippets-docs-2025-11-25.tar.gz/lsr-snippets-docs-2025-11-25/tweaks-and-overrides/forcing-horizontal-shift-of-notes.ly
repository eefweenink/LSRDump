\version "2.22.2"

\header {
  texidoc = "
When the typesetting engine cannot cope, the following syntax can be
used to override typesetting decisions. The units of measure used here
are staff spaces.

"
  doctitle = "Forcing horizontal shift of notes"
}
\relative c' <<
  {
    <d g>2 <d g>
  }
  \\
  {
    <b f'>2
    \once \override NoteColumn.force-hshift = 1.7
    <b f'>2
  }
>>



