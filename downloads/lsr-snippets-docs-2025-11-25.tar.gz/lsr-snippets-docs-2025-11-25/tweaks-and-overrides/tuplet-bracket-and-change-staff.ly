\version "2.22.2"

\header {
  texidoc = "
This snippet shows how to set a tuplet starting in a lower staff and
finishing in the upper one.

"
  doctitle = "Tuplet bracket and change staff"
}
aigues = \relative c' {
  \time 6/8
  s4. 
  \stemDown
  c16[ bes' e] 
  \stemUp
  g c e
  \stemDown
  g8
}

basses = \relative c {
  \time 3/4
  \clef F
  \tweak positions #'(4.5 . 9.5)
  \tweak edge-height #'(1 . -1)
  \tuplet 7/6 {
    c16[ bes' e]
    \change Staff = md
    \stemUp
    g[ c e g]
  }
  s4.s8
}

\new PianoStaff
\with { \omit TimeSignature }
<<
  \new Staff = md \aigues
  \new Staff = mg \basses
>>



