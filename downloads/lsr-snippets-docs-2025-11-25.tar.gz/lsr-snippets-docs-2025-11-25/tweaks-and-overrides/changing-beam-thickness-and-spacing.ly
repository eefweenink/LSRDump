\version "2.22.2"

\header {
  texidoc = "
To make beams thicker or thinner alter the @code{Beam.beam-thickness}
property.  To adjust the spacing between beams alter the
@code{Beam.length-fraction} property.

"
  doctitle = "Changing beam thickness and spacing"
}
\relative f' {
  \time 1/8
  \override Beam.beam-thickness = #0.4
  \override Beam.length-fraction = #0.8
  c32 c c c
  \revert Beam.beam-thickness  % 0.48 is default thickness
  \revert Beam.length-fraction  % 1.0 is default spacing
  c32 c c c
  \override Beam.beam-thickness = #0.6
  \override Beam.length-fraction = #1.3
  c32 c c c 
}


